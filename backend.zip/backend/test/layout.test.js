process.env.NODE_ENV = "test";

let chai = require("chai");
let chaiHttp = require("chai-http");
let server = require("../src/app");
let should = chai.should();
chai.use(chaiHttp);

let Layout = require("../src/models/layout");


describe("Layouts : With DB ", () => {
  describe("layout unit testing with mocha ... ", () => {
    describe("/GET layouts", () => {
      it("it should GET all the layouts", (done) => {
        chai
          .request(server)
          .get("/layouts")
          .end((err, res) => {
            res.should.have.status(200);
            res.body.data.results.should.be.a("array");
            done();
          });
      });
    });
    it("it should POST a layout", (done) => {
      let layout = {
        name: "layout",
        width: "String",
        rows: [],
        columns: [],
        layout_settings: {},
      };
      chai
        .request(server)
        .post("/layouts")
        .send(layout)
        .end((err, res) => {
          res.should.have.status(201);
          res.body.should.be.a("object");
          done();
        });
    });
  });
  describe("/GET/:id layout", () => {
    it("it should GET a layout by the given id", (done) => {
      let layout = new Layout({
        name: "layout",
        width: "String",
        rows: [],
        columns: [],
        layout_settings: {},
      });
      layout.save((err, layout) => {
        chai
          .request(server)
          .get("/layouts/" + layout.id)
          .send(layout)
          .end((err, res) => {
            res.should.have.status(200);
            res.body.should.be.a("object");
            res.body.data.should.have.property("name");
            res.body.data.should.have.property("_id").eql(layout.id);
            done();
          });
      });
    });
    describe("/PUT/:id layout", () => {
      it("it should UPDATE a layout given the id", (done) => {
        let layout = new Layout({
          name: "layout",
          width: "String",
          rows: [],
          columns: [],
          layout_settings: {},
        });
        layout.save((err, layout) => {
          chai
            .request(server)
            .put("/layouts/" + layout.id)
            .send({
              name: "layout updated",
              width: "String",
              rows: [],
              columns: [],
              layout_settings: {},
            })
            .end((err, res) => {
              res.should.have.status(200);
              res.body.should.be.a("object");
              res.body.should.have
                .property("message")
                .eql("successfully updated!");
              done();
            });
        });
      });
    });
    /*
     * Test the /DELETE/:id route
     */
    describe("/DELETE/:id layout", () => {
      it("it should DELETE a layout given the id", (done) => {
        let layout = new Layout({
          name: "layout",
          width: "String",
          rows: [],
          columns: [],
          layout_settings: {},
        });
        layout.save((err, layout) => {
          chai
            .request(server)
            .delete("/layouts/" + layout.id)
            .end((err, res) => {
              res.should.have.status(200);
              res.body.should.be.a("object");
              res.body.should.have
                .property("message")
                .eql("successfully deleted!");
              res.body.should.have.property("data");
              done();
            });
        });
      });
    });
  });
})