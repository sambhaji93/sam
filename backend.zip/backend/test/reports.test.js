process.env.NODE_ENV = "test";
let chai = require("chai");
let chaiHttp = require("chai-http");
let server = require("../src/app");
let should = chai.should();
chai.use(chaiHttp);
let Report = require("../src/models/report");
const reports = require('./../src/controllers/reportsController')

describe("Reports : With DB", () => {
  describe("/GET reports", () => {
    it("it should GET all the reports", (done) => {
      chai
        .request(server)
        .get("/reports")
        .end((err, res) => {
          res.should.have.status(200);
          res.body.data.results.should.be.a("array");
          done();
        });
    });
  });
  /*
   * Test the /DELETE/:id route
   */
  describe("/DELETE/:id report", () => {
    it("it should DELETE a report given the id", (done) => {
      let report = new Report({
        title: "test",
        sections: [],
        stage: "waiting_for_approval",
        report_settings: {},
      });
      report.save((err, report) => {
        chai
          .request(server)
          .delete("/reports/" + report.id)
          .end((err, res) => {
            res.should.have.status(200);
            res.body.should.be.a("object");
            res.body.should.have
              .property("message")
              .eql("successfully deleted!");
            res.body.should.have.property("data");
            done();
          });
      });
    });
  });
})
