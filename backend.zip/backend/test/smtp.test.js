process.env.NODE_ENV = "test";

const expect = require("chai").expect;
const nodemailer = require('nodemailer');
const sendMail = require("../src/utility/smtp")

describe("sendMail()", () => {
    before(async () => {
        const account = await nodemailer.createTestAccount()
        userMailConfig = {
            service: 'mail',
            host: account.smtp.host,
            port: account.smtp.port,
            secure: account.smtp.secure,
            auth: {
              user: account.user,
              pass: account.pass
            },
            logger: false,
            debug: false
        };
        mailOptions = {
            from: account.user,
            to: 'Nodemailer <example@nodemailer.com>',
            subject: 'Sending Email using Node.js',
            text: `Hi this is a test message.`
        };
    })
    it("it should send mail and return an object", async () => {
        const info = await sendMail(mailOptions, userMailConfig);
        expect(info).to.be.a('object');
        expect(info).to.have.property('status')
        expect(info).to.have.property('message')
        expect(info).to.include({ status: true })
    });
});