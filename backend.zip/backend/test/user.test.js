process.env.NODE_ENV = "test";
let chai = require("chai");
let chaiHttp = require("chai-http");
let server = require("../src/app");
let should = chai.should();
chai.use(chaiHttp);

let User = require("../src/models/user");

describe("Users : With DB  ", () => {
  describe("/GET Users", () => {
    it("it should GET all the users", (done) => {
      chai
        .request(server)
        .get("/users")
        .end((err, res) => {
          res.should.have.status(200);
          res.body.data.results.should.be.a("array");
          done();
        });
    });
  });
  describe("/POST User", () => {
    it("it should throw validation error", (done) => {
      let user = {
        first_name: "Amit",
        last_name: "Kumar",
        role: "admin",
      };
      chai
        .request(server)
        .post("/users")
        .send(user)
        .end((err, res) => {
          res.should.have.status(422);
          res.body.should.be.a("object");
          res.body.should.have.property("error");
          done();
        });
    });
  });
})