process.env.NODE_ENV = "test";
let chai = require("chai");
let chaiHttp = require("chai-http");
let server = require("../src/app");
let should = chai.should();
chai.use(chaiHttp);

let Template = require("../src/models/template");

describe("Templates : With DB", () => {
  describe("template unit testing with mocha ... ", () => {
    describe("/GET templates", () => {
      it("it should GET all the templates", (done) => {
        chai
          .request(server)
          .get("/templates")
          .end((err, res) => {
            res.should.have.status(200);
            res.body.data.results.should.be.a("array");
            done();
          });
      });
    });
    it("it should POST a template", (done) => {
      let template = {
        group_name: "group_name",
        description: "lorem ...",
        header: "String",
        footer: "String",
        theme: {},
        adtional_info: {},
        is_page_number: true,
        margin: {
          top: 100,
          bottom: 100,
          left: 100,
          right: 100,
        },
      };
      chai
        .request(server)
        .post("/templates")
        .send(template)
        .end((err, res) => {
          res.should.have.status(201);
          res.body.should.be.a("object");
          done();
        });
    });
  });
  describe("/GET/:id template", () => {
    it("it should GET a template by the given id", (done) => {
      let template = new Template({
        group_name: "group_name",
        description: "lorem ...",
        header: "String",
        footer: "String",
        theme: {},
        adtional_info: {},
        is_page_number: true,
        margin: {
          top: 100,
          bottom: 100,
          left: 100,
          right: 100,
        },
      });
      template.save((err, template) => {
        chai
          .request(server)
          .get("/templates/" + template.id)
          .send(template)
          .end((err, res) => {
            res.should.have.status(200);
            res.body.should.be.a("object");
            res.body.data.should.have.property("group_name");
            res.body.data.should.have.property("_id").eql(template.id);
            done();
          });
      });
    });
    describe("/PUT/:id template", () => {
      it("it should UPDATE a template given the id", (done) => {
        let template = new Template({
          group_name: "group_name",
          description: "lorem ...",
          header: "String",
          footer: "String",
          theme: {},
          adtional_info: {},
          is_page_number: true,
          margin: {
            top: 100,
            bottom: 100,
            left: 100,
            right: 100,
          },
        });
        template.save((err, template) => {
          chai
            .request(server)
            .put("/templates/" + template.id)
            .send({
              group_name: "group_name",
              description: "lorem ...",
              header: "String",
              footer: "String",
              theme: {},
              adtional_info: {},
              is_page_number: true,
              margin: {
                top: 100,
                bottom: 100,
                left: 100,
                right: 100,
              },
            })
            .end((err, res) => {
              res.should.have.status(200);
              res.body.should.be.a("object");
              res.body.should.have
                .property("message")
                .eql("Successfully updated!");
              done();
            });
        });
      });
    });
    /*
     * Test the /DELETE/:id route
     */
    describe("/DELETE/:id template", () => {
      it("it should DELETE a template given the id", (done) => {
        let template = new Template({
          group_name: "group_name",
          description: "lorem ...",
          header: "String",
          footer: "String",
          theme: {},
          adtional_info: {},
          is_page_number: true,
          margin: {
            top: 100,
            bottom: 100,
            left: 100,
            right: 100,
          },
        });
        template.save((err, template) => {
          chai
            .request(server)
            .delete("/templates/" + template.id)
            .end((err, res) => {
              res.should.have.status(200);
              res.body.should.be.a("object");
              res.body.should.have
                .property("message")
                .eql("Successfully deleted!");
              res.body.should.have.property("data");
              done();
            });
        });
      });
    });
  });
})