const mongoose = require("mongoose");
const db = mongoose.connection;

const connectToDb = async () => {
  await mongoose.connect(process.env.MONGO_URL + '&replicaSet=rsName', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
    useCreateIndex: true,
  })
    .then(x => {
      console.log(
        `Connected to Mongo! Database name: "${x.connections[0].name}"`,
      );
    })
    .catch(err => {
      console.error('Error connecting to mongo', err);
    });
  return mongoose;
  // db.on("error", console.error.bind(console, "DB connection error: "));
  // db.on("open", console.error.bind(console, "DB connected: "));
};

module.exports = { connectToDb };
