const { userModel } = require("./../models/user")

/**
 * @ Custom Response Helper
 */
const customResponse = ({ code = 200, message = "", data = {} }) => {
  return {
    success: true,
    code: code,
    message: message,
    data: data,
  };
};

/**
 * @ Custom Pagination Helper
 */
const customPagination = ({ data = [], limit = 15, page = 1 }) => {
  const totalCount = data.length;
  const pageCount = Math.ceil(totalCount / limit);
  const currentPage = page;
  const results = data.slice((page - 1) * limit, page * limit);
  return {
    pageCount,
    totalCount,
    currentPage,
    results,
  };
};

/**
 * This function will just return current users details
 * @param {Current loggedIn user session token} token 
 * @returns 
 */
 const getCurrentUsersDetails = async (token) => {
  const user = await userModel
    .findOne({ token })
    .exec();
  return user
}


module.exports = { customResponse, customPagination, getCurrentUsersDetails };
