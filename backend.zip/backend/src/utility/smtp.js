const nodemailer = require('nodemailer');

/**
 * SMTP connection config
 */
const userMailConfig = {
  service: process.env.SMTP_SERVICE_NAME,
  auth: {
    user: process.env.SMTP_SERVICE_EMAIL_ID,
    pass: process.env.SMTP_SERVICE_EMAIL_PASSWORD
  }
};

/**
 * Create default mail options
 */
const mailOptions = {
  from: process.env.SMTP_SERVICE_EMAIL_ID,
  to: '',
  subject: '',
  text: ''    
};

const sendMail = async (options={}, userMailConfigPassed={}) => {
  const response = {}
  const transporter = nodemailer.createTransport({ ...userMailConfig, ...userMailConfigPassed });
  try {
    const info = await transporter.sendMail({...mailOptions, ...options })
    if (info && info.messageId) {
      response.status = true
      response.message = 'Email sent succesfully'
    }
  } catch (err) {
    response.status = false
    response.message = 'Email sending has failed'
  }
  return response
};

module.exports = sendMail

// helper function : generate html --> template name \
// Report --> publish & reject 