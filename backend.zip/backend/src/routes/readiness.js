var express = require("express");
var router = express.Router();
const mongoose = require("mongoose");
const { checkAmqpConnection } = require('../services/amqp');
require("../app");

router.get("/", async (_req, res, _next) => {
  const info = {
    success: false,
    uptime: process.uptime(),
    message: "",
    amqpConnection: "",
    current_time: new Date(Date.now()).toISOString(),
  };
  try {
    const amqpConnectionState = await checkAmqpConnection() // get amqp server connection state
    switch (amqpConnectionState) {
      case true:
        info.amqpConnection = "AMQP Connected";
        break;
      case false:
        info.amqpConnection = "AMQP Disconnected";
        break;
    }
    const connectionState = mongoose.connection.readyState;

    console.log(connectionState, "connectionState")
    switch (connectionState) {
      case 0:
        info.message = "DB Disconnected";
        res.status(500).send(info);
        break;
      case 1:
        info.message = "DB Conncted";
        info.success = true;
        res.status(200).send(info);
        break;
      case 2:
        info.success = true;
        info.message = "DB connecting...";
        res.status(200).send(info);
        break;
      case 3:
        info.success = true;
        info.message = "DB disconnecting...";
        res.status(200).send(info);
        break;
      default:
        info.message = "Unknown";
        res.status(500).send(info);
    }
  } catch (e) {
    info.message = e;
    res.status(503).send();
  }
});
module.exports = router;
