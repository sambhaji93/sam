var express = require("express");
var router = express.Router();
const { isValidObjectId } = require("../middleware/isValidObjectId");
const { isAdmin } = require("../middleware/auth");

const {
  getReports,
  reportDetail,
  storeReport,
  updateReport,
  destoryReport,
  getAuthors,
  getApprovers,
  approveRejectReport,
  cloneReport,
  colaboratedEditing,
  sectionLocking,
  getReportWorkflow,
  updateReportWorkflow,
  getHistory,
  getReportByVersion,
  restoreFromVersion,
  createNamedVersion,
  getStage,
  generateReportImage,
  getHTMLandPDF,
  shareReport
} = require("../controllers/reportsController");

router.get("/", getReports);
router.get("/authors", getAuthors);
router.get("/approvers", getApprovers);
router.get("/status", getStage);
router.post("/clone", cloneReport);
router.get("/thumbnails/:id", isValidObjectId, generateReportImage);
router.get("/html-pdf/:id", isValidObjectId, getHTMLandPDF);
router.get("/:id", isValidObjectId, reportDetail);
router.get("/:id/histories", isValidObjectId, getHistory);
router.get("/:id/histories/:versionId", getReportByVersion);
router.post("/:reportId/named-versions", createNamedVersion);
router.put("/:reportId/restore-version/:versionId", restoreFromVersion);
router.post("/", storeReport);
router.post("/:id", isValidObjectId, updateReport);
router.put("/:id", isValidObjectId, updateReport);
router.delete("/:id", isValidObjectId, destoryReport);
router.patch("/approve-reject/:id", isAdmin, isValidObjectId, approveRejectReport);
router.post("/colaborated-editing/:id", isValidObjectId, colaboratedEditing);
router.post("/section-locking/:id", isValidObjectId, sectionLocking);
router.patch(
  "/approve-reject/:id",
  isAdmin,
  isValidObjectId,
  approveRejectReport
);
router.get("/workflow/:id", isValidObjectId, getReportWorkflow);
router.patch("/workflow/:id", isValidObjectId, updateReportWorkflow);
router.post("/add-contributors/:id", isValidObjectId, shareReport)

module.exports = router;
