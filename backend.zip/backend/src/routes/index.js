var express = require("express");
var router = express.Router();
var packageJSON = require("../../package.json");

const { reportModel } = require("../models/report");
const templateModel = require("../models/template");
const { xAuthTokenValidation } = require("../middleware/xAuthTokenValidation");
const { isAuthorized } = require("../middleware/auth");
const { auth, getAccount, userLogin } = require("../controllers/userController");
const { getNavMetaInfo } = require("../controllers/menuController");

// const { generatePDF } = require("../controllers/generate");

const healthcheckRoutes = require("./healthcheck");
const readinessRoutes = require("./readiness");
const userRoutes = require("./users");
const templateRoutes = require("./templates");
const reportRoutes = require("./reports");
const layoutRoutes = require("./layouts");
const fileRoutes = require("./uploads");
const notification = require("./notifications");
const comments = require("./comments");
const emails = require("./emails");
const templatesGroup = require("./template-groups");
const mediaRoutes = require("./media");

// router.use("/pdf", generatePDF);
router.use("/healthcheck", healthcheckRoutes);
router.use("/readiness", readinessRoutes);
router.post("/auth", xAuthTokenValidation, auth);
router.get("/account", isAuthorized, getAccount);
router.get("/side-navigations", isAuthorized, getNavMetaInfo);
// router.use("/files", isAuthorized, fileRoutes);
router.use("/users", isAuthorized, userRoutes);
router.use("/templates", isAuthorized, templateRoutes);
router.use("/reports", isAuthorized, reportRoutes);
router.use("/layouts", isAuthorized, layoutRoutes);
router.use("/template-groups", isAuthorized, templatesGroup);
router.use("/notifications/", isAuthorized, notification);
router.use("/comments", isAuthorized, comments);
router.use("/emails", isAuthorized, emails);
router.use("/media", isAuthorized, mediaRoutes);


router.get("/index", async (request, response) => {
  const _id = request.query.report_id;
  const type = request.query.type || 'reports';
  let data;
  if (type == 'templates') {
    data = await templateModel.findById({ _id });
  } else {
    data = await reportModel.findById({ _id });
  }

  response.render("index", {
    title: data.title,
    css: data["gjs-css"],
    html: data["gjs-html"],
  });
});

router.get("/pdf", async (request, response) => {
  const puppeteer = require("puppeteer");
  const constant = require("../utility/constant");
  const reportId = request.query.report_id;
  const url = request.query.url;
  let page_url;

  if (!reportId && !url) {
    return response.status(400).send();
  }

  if (!url) {
    page_url = `${constant.API_URL}/index?report_id=${reportId}`;
    file_path = `public/static/pdf/${reportId}.pdf`;
    console.log("Generating PDF for report id: " + reportId);
  } else {
    page_url = url
    let formatted_url = new Buffer.from(url);
    let filename = formatted_url.toString('base64');
    file_path = `public/static/pdf/${filename}.pdf`;
    console.log("Generating PDF for report url: " + page_url);
  }

  const browser = await puppeteer.launch({
    headless: true,
    ignoreHTTPSErrors: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
    ignoreDefaultArgs: ['--disable-extensions'],
    slowMo: 250,
  });
  console.log("browser launched");
  const page = await browser.newPage();
  console.log("new page has been created");
  await page.goto(page_url, {
    waitUntil: 'networkidle2',
  });

  await page.addStyleTag({ content: 'div{page-break-inside: avoid} body{width: 992px; margin:0 auto;} .overlay-non-editable{display: none}' })
  console.log("page data has been fetched");
  // page.pdf() is currently supported only in headless mode.
  // @see https://bugs.chromium.org/p/chromium/issues/detail?id=753118
  await page.pdf({
    path: file_path,
    format: 'A4',
    printBackground: true,
    width: 992
  });
  console.log("pdf has been generated");

  await browser.close();
  return response.status(200).send({ status: "success" });
});

router.get("/meta-info", (req, res) => {
  return res.status(200).send({ version: packageJSON.version });
});
router.use((error, req, res, next) => {
  const code = error.status || 500;
  const message = error.message || `Internal Server Error`;
  delete error.status;
  delete error.message;
  console.log(
    `Error : "${error}"`,
  );
  const errResponse = {
    success: false,
    code,
    message,
    error,
  };
  res.status(code).send({ ...errResponse });
});

module.exports = router;
