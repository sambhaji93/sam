var express = require("express");
var router = express.Router();
const { isValidObjectId } = require("../middleware/isValidObjectId");

const {
    getEmails,
    emailDetail,
    storeEmail,
    updateEmail,
    destoryEmail,
} = require("../controllers/EmailController");

router.get("/", getEmails);
router.get("/:id", isValidObjectId, emailDetail);
router.post("/", storeEmail);
router.put("/:id", isValidObjectId, updateEmail);
router.delete("/:id", isValidObjectId, destoryEmail);

module.exports = router;