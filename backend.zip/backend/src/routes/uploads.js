var express = require("express");
var router = express.Router();

const { upload, download } = require("../controllers/uploadController");

router.post("/upload", upload);
router.get("/:name", download);

module.exports = router;
