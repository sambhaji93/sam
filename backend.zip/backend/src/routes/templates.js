var express = require("express");
var router = express.Router();
const { isValidObjectId } = require("../middleware/isValidObjectId");

const {
  getTemaltes,
  templateDetail,
  storeTemplate,
  updateTemplate,
  destoryTemplate,
  generateTemplateImage
} = require("../controllers/templateController");

router.get("/thumbnails/:id", generateTemplateImage);
router.get("/", getTemaltes);
router.get("/:id", isValidObjectId, templateDetail);
router.post("/", storeTemplate);
router.post("/:id", isValidObjectId, updateTemplate);
router.put("/:id", isValidObjectId, updateTemplate);
router.delete("/:id", isValidObjectId, destoryTemplate);

module.exports = router;
