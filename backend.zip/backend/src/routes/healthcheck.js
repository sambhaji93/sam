var express = require("express");
var router = express.Router();

router.get("/", async (_req, res, _next) => {
  const healthcheck = {
    success: false,
    uptime: process.uptime(),
    message: "OK",
    current_time: new Date(Date.now()).toISOString(),
  };
  try {
    healthcheck.success = true;
    res.status(200).send(healthcheck);
  } catch (e) {
    healthcheck.message = e;
    res.status(503).send();
  }
});
module.exports = router;
