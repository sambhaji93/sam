var express = require("express");
var router = express.Router();
const { Notifications } = require("../controllers/notificationController");

router.get("/", Notifications);

module.exports = router;

