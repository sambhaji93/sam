var express = require("express");
var router = express.Router();
const { isValidObjectId } = require("../middleware/isValidObjectId");

const {
    getMedia,
    mediaDetail,
    storeMedia,
    updateMedia,
    destoryMedia,
} = require("../controllers/mediaController");

router.get("/", getMedia);
router.get("/:id", isValidObjectId, mediaDetail);
router.post("/", storeMedia);
router.put("/:id", isValidObjectId, updateMedia);
router.delete("/:id", isValidObjectId, destoryMedia);

module.exports = router;