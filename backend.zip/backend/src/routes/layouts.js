var express = require("express");
var router = express.Router();
const { isValidObjectId } = require("../middleware/isValidObjectId");

const {
  getLayout,
  layoutDetail,
  storelayout,
  updatelayout,
  destorylayout,
} = require("../controllers/layoutController");

router.get("/", getLayout);
router.get("/:id", isValidObjectId, layoutDetail);
router.post("/", storelayout);
router.put("/:id", isValidObjectId, updatelayout);
router.delete("/:id", isValidObjectId, destorylayout);

module.exports = router;
