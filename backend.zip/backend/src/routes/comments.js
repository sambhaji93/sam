var express = require("express");
var router = express.Router();
const { isValidObjectId } = require("../middleware/isValidObjectId");

const {
    getComment,
    commentDetail,
    storeComment,
    updateComment,
    destoryComment,
} = require("../controllers/commentController");

router.get("/", getComment);
router.get("/:id", isValidObjectId, commentDetail);
router.post("/", storeComment);
router.put("/:id", isValidObjectId, updateComment);
router.delete("/:id", isValidObjectId, destoryComment);

module.exports = router;