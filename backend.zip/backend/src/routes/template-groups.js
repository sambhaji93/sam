var express = require("express");
var router = express.Router();
const { isValidObjectId } = require("../middleware/isValidObjectId");

const {
    getTemalteGroups,
    templateGroupDetail,
    storeTemplateGroup,
    updateTemplateGroup,
    destoryTemplateGroup,
} = require("../controllers/templateGroupController");

router.get("/", getTemalteGroups);
router.get("/:id", isValidObjectId, templateGroupDetail);
router.post("/", storeTemplateGroup);
router.put("/:id", isValidObjectId, updateTemplateGroup);
router.delete("/:id", isValidObjectId, destoryTemplateGroup);

module.exports = router;
