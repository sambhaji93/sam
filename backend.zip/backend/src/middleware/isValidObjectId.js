const mongoose = require("mongoose");

const { customResponse } = require("../utility/helper");

const isValidObjectId = async (req, res, next) => {
  let code, message;
  const _id = req.params.id;
  const isValid = mongoose.Types.ObjectId.isValid(_id);
  if (!isValid) {
    next({ status: 422, message: `Invalid mongoose ObjectId  : ${_id}` });
  }
  next();
};
module.exports = { isValidObjectId };
