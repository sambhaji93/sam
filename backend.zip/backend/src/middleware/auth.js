const jwt = require("jsonwebtoken");

const { userModel } = require("../models/user");
const { customResponse } = require("../utility/helper");

const accessDeniedResponse = (res, message, code) => {
  const resData = customResponse({ code, message });
  return res.status(code).send(resData);
}

const isAuthorized = async (req, res, next) => {
  if (process.env.NODE_ENV == "test") {
    next();
    return;
  }
  const authorizationHeaader = req.headers.authorization;
  const permission = req.headers.permission;
  if (authorizationHeaader) {
    const token = req.headers.authorization.split(" ")[1]; // Bearer <token>
    const user = await userModel.findOne({ token }).exec();
    const isAllowed = user && user.user_permissions.indexOf(permission);
    if (!user) {
      accessDeniedResponse(res, "Authentication error. You are unauthorized.", 401)
    }
    // if(isAllowed) {
    //   accessDeniedResponse(res, "Authentication error. You are unauthorized.", 401)
    // }
    next();
  } else {
    accessDeniedResponse(res, "Authentication error. Token required.", 401);
  }
};

const isAdmin = async (req, res, next) => {
  const token = req.headers.authorization.split(" ")[1];
  const user = await userModel.findOne({ token }).exec();
  // Need to changes as per the HTTP methods
  if (user && user.role === "admin") {
    next();
  } else {
    return res
      .status(403)
      .send({
        success: false,
        message: "You are not authorized to perform this action",
      });
  }
};

module.exports = { isAuthorized, isAdmin };
