const util = require("util");
const multer = require("multer");

const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "public");
  },
  filename: (req, file, cb) => {
    const ext = file.mimetype.split("/")[1];
    cb(null, `files/${file.mimetype.split("/")[0]}-${Date.now()}.${ext}`);
  },
});

const multerFilter = (req, file, cb) => {
  const allowedFiles = ["image", "video"];
  if (allowedFiles.includes(file.mimetype.split("/")[0])) {
    cb(null, true);
  } else {
    cb(new Error("Only Image and Video is allowed!!"), false);
  }
};

const upload = multer({
  storage: multerStorage,
  fileFilter: multerFilter,
}).single("file");

let uploadFileMiddleware = util.promisify(upload);
module.exports = uploadFileMiddleware;
