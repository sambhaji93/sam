/**
 * Required all dependencies
 */
 const { reportModel } = require("./../models/report");
 const { userModel } = require("./../models/user");
 const { sendMailAmqp } = require("./amqp");
 const { saveNotification } = require("./notificationService");
 const { publishReports, drupleWorkFlow } = require("./drupleService");
 const { getCurrentUsersDetails } = require("./../utility/helper");
 /**
  * 1. Draft
  * 2. Send for Approval
  * 3. Aproved
  * 4. Reject
  * 5. Send for publish
  * 6. Publish
  * 7. Publish format (HTM/PDF) or both
  * 8. Change Request
  *
  * ****** Mapping ********
  * 1: [2]
  * 2: [3,4]
  * 3: [5]
  * 4: [8]
  * 8: [1]
  * 5: [6,4]
  * 6: [7]
  */
 
 /**
  * Send mail to authers
  * @param {*} authorId
  * @param {*} status
  */
 const sendMailToUser = async (req, userId, status, referenceId, message) => {
   const userDetails = await userModel.findById(userId);
   const options = {
     to: userDetails.email,
     subject: "Report status",
   };
   options.text = `
      Hi ${userDetails.first_name} ${userDetails.last_name}, ${message}`;
   saveNotification(req, "reports", status, message, referenceId, userId);
   sendMailAmqp(options);
 };
 
 /**
  * Send Email Notification
  * @param {*} payload
  */
 const sendEmailNotification = async (req, payload, reportDetails) => {
   let userId;
   let message;
   const authorizationHeaader = req.headers.authorization.split(" ")[1];
   const currentUserDetails = await getCurrentUsersDetails( authorizationHeaader);
   const userDetails = await userModel.findById(reportDetails.author);

   switch (payload.stage) {
    case "send_for_approval":
      // Send notification to all reviewers
      message = `${userDetails.first_name} has sent report ${reportDetails.title} for approval.`;
      payload.reviewers.forEach((userId) => {
        sendMailToUser(req, userId, payload.stage, reportDetails._id, message);
      });
      break;
    case "send_for_publish":
      // Send notification to reviewers and author also when report published
      message = `${userDetails.first_name} has sent report ${reportDetails.title} for publish.`;
      const reviewers = reportDetails.reviewers;
      reviewers.forEach((userId) => {
        sendMailToUser(req, userId, payload.stage, reportDetails._id, message);
      });
      break;
    case "published":
      message = `${currentUserDetails.first_name} has published your report ${reportDetails.title}.`;
      userId = reportDetails.author;
      sendMailToUser(req, userId, payload.stage, reportDetails._id, message);
      break;
    case "approve":
      message = `${currentUserDetails.first_name} has approved your report ${reportDetails.title}.`;
      userId = reportDetails.author;
      sendMailToUser(req, userId, payload.stage, reportDetails._id, message);
      break;
    case "reject":
      message = `${currentUserDetails.first_name} has rejected your report ${reportDetails.title}.`;
      userId = reportDetails.author;
      sendMailToUser(req, userId, payload.stage, reportDetails._id, message);
      break;
    default:
      userId = reportDetails.author;
      sendMailToUser(req, userId, payload.stage, reportDetails._id, "your report has been updated");
      break;
  }
 };
 /**
  * Get workflow from drupal
  * @param {*} req
  * @param {*} reportId
  * @param {*} payload
  * @returns
  */
 const getWorkFlow = async (req, reportId, payload) => {
   // Fetch report detail before update.
   let results;
   try {
     const reportDetails = await reportModel.findOne({ _id: reportId });
     let drupalPayload = {};
     if (reportDetails["stage"] == "published") {
       drupalPayload = { report_id: reportId };
     } else {
       drupalPayload = { current_state: reportDetails["stage"] };
     }
     const possibleNextStage = await drupleWorkFlow(req, drupalPayload);
     // results = { success: true, data: Object.keys(possibleNextStage) };
     results = { success: true, data: possibleNextStage };
   } catch (error) {
     results = { success: false, data: [] };
   }
   return results;
 };
 
 /**
  * This workflow just check current details and update as per the workflow mapping
  * @param {ReportId} reportId
  * @param {Requested payload} payload
  * @returns
  */
 const updateWorkFlow = async (req, reportId, payload) => {
   let results;
   try {
     const details = await reportModel.findOneAndUpdate(
       { _id: reportId },
       { ...req.body },
       { new: true }
     );
     // TODO: send data to drupal
 
     if (payload.stage === "published") {
       // TODO: Just need to pass reportId to drupal
       // Drupal will communicate with our DB to get reports details
       await publishReports(req, details);
     }
     sendEmailNotification(req, payload, details);
     results = {
       success: true,
       message: "Report has been updated successfully!",
     };
   } catch (error) {
     results = { success: false, message: "Something went wrong!" };
   }
 
   return results;
 };
 
 module.exports = {
   updateWorkFlow,
   getWorkFlow,
 }; 