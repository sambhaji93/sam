const { NotificationModel } = require('./../models/notification')
const { getCurrentUsersDetails } = require('./../utility/helper')

/**
 * This function will just store notification details into notification collections
 * @param {*} req 
 * @param {*} type 
 * @param {*} status 
 * @param {*} notification 
 * @param {*} referenceId 
 */
const saveNotification = async (req, type, status, notification, referenceId, notifyUserId=null) => {
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    let author;
    if(notifyUserId) {
        author = [notifyUserId]
    } else {
        const user = await getCurrentUsersDetails(authorizationHeaader);
        author = [user._id];
    }
    const data = new NotificationModel({
        type,
        author,
        status,
        notification,
        referenceId
    });
    try {
        await data.save();
    } catch (error) {
        // This function will just logs some error of current users
      console.error(`There is some error in ${type}`, error.message, user);
    } 
}

module.exports = {
    saveNotification
}