const EmailModel = require("../models/email");

/**
 * This function will get all emails from email collection
 * @param {*} searchString 
 * @param {*} startDate 
 * @param {*} endDate 
 * @param {*} sortBy 
 */
const findEmails = async (searchString, startDate, endDate, sortBy) => {
    const data = await EmailModel
        .find(
            {
                created_at: {
                    $gte: startDate,
                    $lte: endDate,
                },
                $and: [{ $and: searchString }],
            },
            null,
            { sort: { ...sortBy } }
        )
        .sort({ created_at: -1 })
    return data;
}

/**
 * This function get an email details
 * @param {*} emailId
 */
const findEmailDetail = async (emailId) => {
    const data = await EmailModel.findById({ _id: emailId });
    return data
}

/**
 * This function will store email details into email collection
 * @param {*} emailData
 */
const saveEmail = async (emailData) => {
    const data = await new EmailModel(emailData);
    await data.save();
    return data
}

/**
 * This function will update email details into email collection
 * @param {*} emailId
 * @param {*} req
 */
const updateEmailData = async (emailId, emailData) => {
    const data = await EmailModel.findOneAndUpdate(
        { _id: emailId },
        { ...emailData },
        { new: true }
    );
    if (data) await data.save();
    return data
}

/**
 * This function will delete email details from email collection
 * @param {*} emailId
 */
const deleteEmail = async (emailId) => {
    const data = await EmailModel.findByIdAndDelete({ _id: emailId });
    return data
}

module.exports = { findEmails, findEmailDetail, saveEmail, updateEmailData, deleteEmail }