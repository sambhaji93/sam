const axios = require("axios");
const constant = require('../utility/constant');

/**
 * Get Drupal AuthToken from req header
 * @param {*} req
 * @returns
 */
const getAuthToken = (req) => {
  const authToken = req.headers.authorization;
  return authToken;
};

/**
 * This workflow just check current details and update as per the workflow mapping
 * @param {ReportId} reportId
 * @param {Requested payload} payload
 * @returns
 */
//   https://test-cms-iam.eversana.com/
const publishReports = async (req, data) => {
  try {
    const authToken = getAuthToken(req);
    // Send a POST request
    const response = await axios({
      method: "post",
      url: constant.DRUPAL_URL + "/generate_report",
      data: data,
      headers: {
        "Content-Type": "application/json",
        Authorization: `${authToken}`,
      },
    });
    return response;
  } catch (e) { }
};
/**
 * To get reports next stage from druple
 * @param {*} payload
 */
const drupleWorkFlow = async (req, payload) => {
  const authToken = getAuthToken(req);
  // Send a POST request
  const response = await axios({
    method: "post",
    url: constant.DRUPAL_URL + "/get_workflow_states",
    data: payload,
    headers: {
      "Content-Type": "application/json",
      Authorization: `${authToken}`,
    },
  });
  return response.data;
};

module.exports = {
  publishReports,
  drupleWorkFlow,
};
