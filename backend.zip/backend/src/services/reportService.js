const { getCurrentUsersDetails } = require("./../utility/helper");
const { reportEmitEvent, sectionEmitEvent } = require("./../socket/socket.io");

/**
 * This function will emit an event for colaborated editing
 * @param {*} req
 * @param {*} id # ReportId
 */
const colaboratedEditingService = async (id, req) => {
  const authorizationHeaader = req.headers.authorization.split(" ")[1];
  const user = await getCurrentUsersDetails(authorizationHeaader);
  const auther = [user];
  const text = req.body.text;
  const nameSapceEventDetails = { id, auther: auther, text: text };
  try {
    reportEmitEvent(nameSapceEventDetails);
    return "Event created successfully!";
  } catch (error) {
    throw error;
  }
};

/**
 * This function will create an section locking socket.io events
 * @param {*} req
 * @param {*} id # ReportId
 */
const sectionLockingService = async (id, req) => {
  const authorizationHeaader = req.headers.authorization.split(" ")[1];
  const user = await getCurrentUsersDetails(authorizationHeaader);
  const auther = [user];
  const data = req.body.data;
  const ccid = req.body.ccid;
  const model = req.body.model;
  const status = req.body.status;
  const active_author = req.body.active_author;

  const nameSapceEventDetails = {
    id,
    auther: auther,
    data,
    ccid,
    status,
    model,
    active_author
  };
  try {
    sectionEmitEvent(nameSapceEventDetails);
    return "Section locking event created successfully!";
  } catch (error) {
    throw error;
  }
};

module.exports = {
  colaboratedEditingService,
  sectionLockingService,
};
