const amqp = require('amqplib')
const amqpServer = process.env.AMQP_URL
var channel;

/**
 * check Amqp Connection status
 */
const checkAmqpConnection = async () => {
    let connectionStatus = true
    try {
        await amqp.connect(amqpServer)
    } catch (err) {
        connectionStatus = false
    }
    return connectionStatus
}

/**
 * connect to Amqp server
 */
const connectToAmqp = async () => {
    try {
        const connection = await amqp.connect(amqpServer)
        channel = await connection.createChannel()
        console.log('amqp server connected')
    } catch (err) {
        console.error('amqp server connection failed')
    }
}

/**
 * send mail via amqp server
 * 
 *  mailConfig = {
        to: to email id,
        subject: mail subject text string,
        text: mail description text string
    };
 */
const sendMailAmqp = (mailConfig={ to: '', subject: '', text: '' }) => {
    channel.sendToQueue('mail', Buffer.from(JSON.stringify(mailConfig)))
}

module.exports = { checkAmqpConnection, connectToAmqp, sendMailAmqp }