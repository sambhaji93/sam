const mongoose = require("mongoose");

const UserGroupSchema = new mongoose.Schema(
  {
    group_name: {
      type: String,
      required: true,
    },
    user_ids: {
      type: Array,
      required: true,
    }
  },
  { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);

const userGroupModel = mongoose.model("UserGroup", UserGroupSchema);

module.exports = { userGroupModel, UserGroupSchema};
