const mongoose = require("mongoose");

const EmailDbSchema = new mongoose.Schema(
  {
    title: String,
    category: String,
    tag: String,
    body: [{
      type: String,
    }],
    html: String,
    attachments: [{
      type: String,
      required: false,
    }],
    status: {
      type: String,
      enum: ["draft", "active", "inactive"],
      default: "draft",
    },
    created_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    updated_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    deleted_at: { type: Date, required: false },
  },
  { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);
const emailModel = mongoose.model("Email", EmailDbSchema);

module.exports = emailModel;
