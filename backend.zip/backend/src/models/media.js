const mongoose = require("mongoose");

const MediaDbSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, "Uploaded file must have a name"],
        },
        type: {
            type: String,
            required: [true, "Uploaded file must have a type"],
        },
        src: {
            type: String,
            required: false,
        },
        tag: String,
        height: String,
        width: String,
        uploaded_by: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
        updated_by: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
        status: {
            type: String,
            enum: ["active", "deleted"],
            default: "active",
        },
        created_by: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
        updated_by: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
        deleted_at: { type: Date, required: false },
    },
    { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);
const mediaModel = mongoose.model("Media", MediaDbSchema);

module.exports = mediaModel;
