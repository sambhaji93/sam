const mongoose = require("mongoose");

const TemplateGroupDbSchema = new mongoose.Schema(
    {
        name: String,
        description: String,
        status: {
            type: String,
            enum: ["active", "deleted"],
            default: "active",
        },
        created_by: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
        updated_by: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
        deleted_at: { type: Date, required: false },
    },
    { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);
const templateGroupModel = mongoose.model("TemplateGroup", TemplateGroupDbSchema);

module.exports = templateGroupModel;
