const mongoose = require("mongoose");

const TemplateDbSchema = new mongoose.Schema(
  {
    title: String,
    "gjs-assets": String,
    "gjs-components": String,
    "gjs-css": String,
    "gjs-html": String,
    "gjs-styles": String,
    thumbnail: String,
    "group": {
      type: mongoose.Schema.Types.ObjectId,
      ref: "TemplateGroup",
      required: false,
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    status: {
      type: String,
      enum: ["active", "deleted"],
      default: "active",
    },
    created_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    updated_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    deleted_at: { type: Date, required: false },
  },
  { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);
const templateModel = mongoose.model("Template", TemplateDbSchema);

module.exports = templateModel;
