const { string } = require('joi')
const mongoose = require('mongoose')

const NotificationSchema = new mongoose.Schema(
    {
        type: String,
        author: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },
        status: String,
        notification: String,
        referenceId: {
            type: mongoose.Schema.Types.ObjectId,
        },
        deleted_at: { type: Date, required: false }, 
    },
    { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);

const NotificationModel = mongoose.model('Notification', NotificationSchema)

module.exports = {
    NotificationModel
}