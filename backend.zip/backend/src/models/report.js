const mongoose = require("mongoose");

const ReportDbSchema = new mongoose.Schema(
  {
    title: String,
    "gjs-assets": String,
    "gjs-components": String,
    "gjs-css": String,
    "gjs-html": String,
    "gjs-styles": String,
    report_settings: Object,
    sections: Array,
    isPublish: {
      type: Boolean,
      default: false
    },
    thumbnail: String,
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    contributors: Array({
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    }),
    reviewers: Array({
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    }),
    active_author: [
      {
        user_id: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
          required: false,
        },
        first_name: String,
        last_name: String,
        ccid: String
      }
    ],
    stage: {
      type: String,
      default: "draft",
    },
    status: {
      type: String,
      enum: ["active", "deleted"],
      default: "active",
    },
    created_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    updated_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
    },
    deleted_at: { type: Date, required: false },
  },
  { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);
const reportModel = mongoose.model("Report", ReportDbSchema);


const ReportVeriosnSchema = new mongoose.Schema({
  version_name: String,
  version: String,
  report_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: false,
  },
  report: ReportDbSchema,
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: false,
  },
}, { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } })
const reportVerionsModel = mongoose.model("ReportVersion", ReportVeriosnSchema);

module.exports = { reportModel, reportVerionsModel };
