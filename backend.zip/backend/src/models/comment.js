const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema(
    {
        component_id: Number,
        is_child: {
            type: Boolean,
            require: false,
            default: false
        },
        reply: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: "comments",
            required: false,
        }],
        message: {
            type: String,
            require: true
        },
        report_id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Report",
            required: true,
        },
        sender_id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
        tagged_users: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        }],
        stage: {
            type: String,
            enum: ["Pending", "Resolved"],
            default: "Pending",
        },
        offsetx: Number,
        offsety: Number,
        created_by: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
        updated_by: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: false,
        },
    },

    { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);
const commentModel = mongoose.model("comments", commentSchema);

module.exports = commentModel;