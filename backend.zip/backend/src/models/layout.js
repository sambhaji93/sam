const mongoose = require("mongoose");

const LayoutDbSchema = new mongoose.Schema(
  {
    name: String,
    width: String,
    rows: Array,
    columns: Array,
    layout_settings: Object,
    status: {
      type: String,
      enum: ["active", "deleted"],
      default: "active",
    },
    deleted_at: { type: Date, required: false },
  },
  { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } }
);
const layoutModel = mongoose.model("Layout", LayoutDbSchema);

module.exports = layoutModel;
