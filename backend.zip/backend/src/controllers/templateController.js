const { customResponse, customPagination } = require("../utility/helper");
const { addTemplateSchema } = require("../schema/templateSchema");
const templateModel = require("../models/template");
const { generatePriviewImage } = require("../controllers/generate")
const constant = require("../utility/constant");
const fs = require('fs')
const { getCurrentUsersDetails } = require("../utility/helper");

const getTemaltes = async (req, res, next) => {
  /* 	#swagger.tags = ['Template']
      #swagger.description = 'Get templates list'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
      #swagger.parameters['page'] = {
        in: 'query',
        type: 'integer',
        description: 'Page number' 
      }
      #swagger.parameters['limit'] = {
        in: 'query',
        type: 'integer',
        description: 'Data limit per page' 
      }
      #swagger.parameters['start_date'] = {
        in: 'query',
        type: 'Date',
      }
      #swagger.parameters['end_date'] = {
        in: 'query',
        type: 'Date',
      }
      #swagger.parameters['title'] = {
        in: 'query',
        type: 'string'
      }
      #swagger.parameters['sort_by'] = {
        in: 'query',
        type: 'string',
        description: 'Ex created_at_asc , created_at_desc, updated_at_asc,updated_at_desc, title_asc, title_desc'
      }
  */
  let code;
  let todayDate = new Date();
  let startDate = new Date();
  let sort_by;
  startDate.setDate(startDate.getDate() - 365);
  const page = req.query.page ? req.query.page : 1;
  const limit = req.query.limit ? req.query.limit : 15;
  const start_date = req.query.start_date
    ? new Date(req.query.start_date)
    : startDate;
  let end_date = req.query.end_date ? new Date(req.query.end_date) : todayDate;
  end_date.setDate(end_date.getDate() + 1);
  const searchString = [
    {
      title: { $regex: "" },
    },
  ];
  switch (req.query.sort_by) {
    case "created_at_asc":
      sort_by = { created_at: 1 };
      break;
    case "created_at_desc":
      sort_by = { created_at: -1 };
      break;
    case "updated_at_asc":
      sort_by = { updated_at: 1 };
      break;
    case "updated_at_desc":
      sort_by = { updated_at: -1 };
      break;
    case "title_asc":
      sort_by = { title: 1 };
      break;
    case "title_desc":
      sort_by = { title: -1 };
      break;
    default:
      sort_by = { created_at: 1 };
      break;
  }
  if (req.query.title) {
    searchString.push({
      title: { $regex: new RegExp(req.query.title, "i") },
    });
  }
  if (req.query.group) {
    searchString.push({
      group: req.query.group
    });
  }


  try {
    code = 200;
    const templateData = await templateModel.find(
      {
        created_at: {
          $gte: start_date,
          $lte: end_date,
        },
        $and: [{ $and: searchString }],
      },
      { title: 1, group: 1, thumbnail: 1, created_at: 1, updated_at: 1 },
      { sort: { ...sort_by } }
    ).populate("group").populate("updated_by", "_id first_name last_name");

    const data = customPagination({ data: templateData, page, limit });
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

/**
 * Function that list and search temaplates.
 */
const templateDetail = async (req, res, next) => {
  /* 	#swagger.tags = ['Template']
      #swagger.description = 'Get template Detail'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
  */
  let code;
  const _id = req.params.id;
  try {
    code = 200;
    const data = await templateModel.findById({ _id }).populate("group");
    if (!data) {
      next({ status: 404, message: "Not found with id " + _id });
    }
    return res.status(code).send(data);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const storeTemplate = async (req, res, next) => {
  /* 	#swagger.tags = ['Template']
      #swagger.description = 'Store new template'
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
          $title: "String",
          "gjs-assets": "String",
          "gjs-components": "String",
          "gjs-css": "String",
          "gjs-html": "String",
          "gjs-styles": "String",
        }
      }
  */
  try {
    let code = 201;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.created_by = currentUserDetails._id;
    req.body.thumbnail = req.body.thumbnail = `${constant.API_URL}/static/screenshot/templates/gjs_default_placeholder.jpg`
    const data = new templateModel(req.body);
    await data.save();
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const updateTemplate = async (req, res, next) => {
  /* 	#swagger.tags = ['Template']
      #swagger.description = 'Update Template' 
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
          $title: "String",
          "gjs-assets": "String",
          "gjs-components": "String",
          "gjs-css": "String",
          "gjs-html": "String",
          "gjs-styles": "String",
        }
      }
  */
  let code, message;
  const _id = req.params.id;
  const authorizationHeaader = req.headers.authorization.split(" ")[1];
  const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
  req.body.updated_by = currentUserDetails._id;
  try {
    code = 200;
    message = "Successfully updated!";
    const data = await templateModel.findOneAndUpdate(
      { _id },
      { ...req.body },
      { new: true }
    );
    if (!data) {
      code = 404;
      message = "Not Found";
      const resData = customResponse({
        code,
        message,
        err: {},
      });
      return res.status(code).send(resData);
    }
    await data.save();
    const resData = customResponse({
      code,
      data,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const destoryTemplate = async (req, res, next) => {
  /* 	#swagger.tags = ['Template']
      #swagger.description = 'Delete Template'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
  */
  let code, message;
  const _id = req.params.id;
  try {
    code = 200;
    const data = await templateModel.findByIdAndDelete({ _id });
    if (!data) {
      code = 404;
      message = "Not Found";
      const resData = customResponse({
        code,
        message,
        err: {},
      });
      return res.status(code).send(resData);
    }
    message = "Successfully deleted!";
    const resData = customResponse({
      code,
      data,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
const generateTemplateImage = async (req, res, next) => {
  const _id = req.params.id;
  try {
    await generatePriviewImage(_id, 'templates');
    const thumbnail = `${constant.API_URL}/static/screenshot/templates/${_id}.jpeg`;
    const data = await templateModel.findOneAndUpdate(
      { _id },
      { thumbnail },
      { new: true }
    );
    await data.save();
    res.status(200).send({ success: true, message: "Thumbnail generated successfully" });
  } catch (error) {
    next(error)
  }
}
module.exports = {
  getTemaltes,
  templateDetail,
  storeTemplate,
  updateTemplate,
  destoryTemplate,
  generateTemplateImage
};
