const { customResponse, customPagination } = require("../utility/helper");
const mediaModel = require("../models/media");
const uploadFile = require("../middleware/upload");
const { getCurrentUsersDetails } = require("../utility/helper");

const getMedia = async (req, res, next) => {
    /* #swagger.tags = ['Media']
        #swagger.description = 'Get Media list'
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
        #swagger.parameters['page'] = {
          in: 'query',
          type: 'integer',
          description: 'Page number' 
        }
        #swagger.parameters['limit'] = {
          in: 'query',
          type: 'integer',
          description: 'Data limit per page' 
        }
        #swagger.parameters['start_date'] = {
          in: 'query',
          type: 'Date',
        }
        #swagger.parameters['end_date'] = {
          in: 'query',
          type: 'Date',
        }
        #swagger.parameters['name'] = {
          in: 'query',
          type: 'string'
        }
        #swagger.parameters['sort_by'] = {
          in: 'query',
          type: 'string',
          description: 'Ex created_at_asc , created_at_desc, updated_at_asc,updated_at_desc, name_asc, name_desc'
        }
    */
    let code, sort_by;
    let todayDate = new Date();
    let startDate = new Date();
    startDate.setDate(startDate.getDate() - 365);
    const page = req.query.page ? req.query.page : 1;
    const limit = req.query.limit ? req.query.limit : 15;
    const start_date = req.query.start_date
        ? new Date(req.query.start_date)
        : startDate;
    let end_date = req.query.end_date ? new Date(req.query.end_date) : todayDate;
    end_date.setDate(end_date.getDate() + 1);
    const searchString = [
        {
            name: { $regex: "" },
        },
    ];
    if (req.query.name) {
        searchString.push({
            name: { $regex: new RegExp(req.query.name, "i") },
        });
    }
    if (req.query.type) {
        searchString.push({
            type: { $regex: new RegExp(req.query.type, "i") },
        });
    }
    if (req.query.tag) {
        searchString.push({
            tag: { $regex: new RegExp(req.query.tag, "i") },
        });
    }
    switch (req.query.sort_by) {
        case "created_at_asc":
            sort_by = { created_at: 1 };
            break;
        case "created_at_desc":
            sort_by = { created_at: -1 };
            break;
        case "updated_at_asc":
            sort_by = { updated_at: 1 };
            break;
        case "updated_at_desc":
            sort_by = { updated_at: -1 };
            break;
        case "name_asc":
            sort_by = { name: 1 };
            break;
        case "name_desc":
            sort_by = { name: -1 };
            break;
        default:
            sort_by = { created_at: 1 };
            break;
    }

    try {
        code = 200;
        const mediaData = await mediaModel
            .find(
                {
                    created_at: {
                        $gte: start_date,
                        $lte: end_date,
                    },
                    $and: [{ $and: searchString }],
                },
                { name: 1, src: 1, tag: 1, type: 1, created_at: 1, updated_at: 1 },
                { sort: { ...sort_by } }
            )
            .populate("updated_by", "_id first_name last_name")
            .sort({ created_at: -1 });
        const data = customPagination({ data: mediaData, page, limit });
        const resData = customResponse({ code, data });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};

/**
 * Function that list and search temaplates.
 */
const mediaDetail = async (req, res, next) => {
    /*  #swagger.tags = ['Media']
        #swagger.description = 'Get Media Detail'
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
    */
    let code;
    const _id = req.params.id;
    try {
        code = 200;
        const data = await mediaModel.findById({ _id });
        if (!data) {
            next({ status: 404, message: "Not found with id " + _id });
        }
        const resData = customResponse({ code, data });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const storeMedia = async (req, res, next) => {
    /* 	#swagger.tags = ['Media']
        #swagger.description = 'Store new Media'
        #swagger.security = [{
            "apiKeyAuth": []
        }] 
        #swagger.parameters['obj'] = {
          in: 'body',
          schema: {
              $name: 'test',
              $file : 'Image url',
              $tag : 'Recent',
              $type : 'Image'
          }
        }
    */
    let code, data;
    try {
        code = 201;
        const authorizationHeaader = req.headers.authorization.split(" ")[1];
        const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
        req.body.created_by = currentUserDetails._id;

        if (req.body.src) {
            req.body.type = req.body.type || 'image';
            data = new mediaModel(req.body);
            data.save();
        } else {
            await uploadFile(req, res);
            if (req.file == undefined) {
                code = 422;
                message = "Please upload a file!";
                const resData = customResponse({
                    code,
                    message,
                });
                return res.status(code).send(resData);
            }
            const reqData = {
                name: req.body.name || req.file.originalname,
                type: req.file.mimetype.split("/")[0],
                src: `${process.env.API_URL}/${req.file.filename}`,
                tag: req.body.tag || 'Recent'
            };
            data = new mediaModel(reqData);
            data.save();
        }
        const resData = customResponse({ code, data });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const updateMedia = async (req, res, next) => {
    /* 	#swagger.tags = ['Media']
        #swagger.description = 'Update Media' 
        #swagger.security = [{
            "apiKeyAuth": []
        }]
        #swagger.parameters['obj'] = {
          in: 'body',
          schema: {
            $name: 'test',
            $file : '',
            $tag : 'Recent'
          }
        } 
    */
    let code, message;
    const _id = req.params.id;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.updated_by = currentUserDetails._id;
    try {
        code = 200;
        message = "successfully updated!";
        const data = await mediaModel.findOneAndUpdate(
            { _id },
            { ...req.body },
            { new: true }
        );
        if (!data) {
            code = 404;
            message = "Not Found";
            const resData = customResponse({
                code,
                message,
                err: {},
            });
            return res.status(code).send(resData);
        }
        await data.save();
        const resData = customResponse({
            code,
            data,
            message,
        });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const destoryMedia = async (req, res, next) => {
    /* 	#swagger.tags = ['Media']
        #swagger.description = 'Delete Media'
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
    */
    let code, message;
    const _id = req.params.id;
    try {
        code = 200;
        const data = await mediaModel.findByIdAndDelete({ _id });
        if (!data) {
            code = 404;
            message = "Not Found";
            const resData = customResponse({
                code,
                message,
                err: {},
            });
            return res.status(code).send(resData);
        }
        message = "successfully deleted!";
        const resData = customResponse({
            code,
            data,
            message,
        });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};

module.exports = {
    getMedia,
    mediaDetail,
    storeMedia,
    updateMedia,
    destoryMedia,
};
