const jwt = require("jsonwebtoken");
const { addUserSchema } = require("../schema/userSchema");
const { customResponse, customPagination } = require("../utility/helper");
const constant = require("../utility/constant");

const { userModel } = require("../models/user");
const { userGroupModel } = require("../models/userGroup");

const getUserList = async (req, res, next) => {
  /* 	#swagger.tags = ['User']
      #swagger.description = 'Get users list'
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.parameters['page'] = {
        in: 'query',
        type: 'integer',
        description: 'Page number' 
      }
      #swagger.parameters['limit'] = {
        in: 'query',
        type: 'integer',
        description: 'Data limit per page' 
      }
      #swagger.responses[200] = {
        schema:{
          "status": "success",
          "code": 200,
          "message": "",
          "data": {
            "pageCount": 1,
            "totalCount": 1,
            "currentPage": 1,
            "results": [
              {
                "_id": "610d090636ba149966bd3b55",
                "first_name": "Jhon",
                "last_name": "Doe",
                "email": "jhon@valuebound.com",
                "role": "admin"
              }
            ]
          },
          "error": {}
        }
      }
  */
  let code, message;
  const searchString = [{ role: { $regex: "" } }];

  const page = req.query.page ? req.query.page : 1;
  const limit = req.query.limit ? req.query.limit : 15;
  if (req.query.first_name) {
    searchString.push({ first_name: { $regex: new RegExp(req.query.first_name, "i") } });
  }
  if (req.query.last_name) {
    searchString.push({ last_name: req.query.last_name });
  }
  if (req.query.email) {
    searchString.push({ email: req.query.email });
  }
  try {
    code = 200;
    const users = await userModel.find({
      $and: [{ $and: searchString }],
    });
    const data = customPagination({ data: users, page, limit });
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

const getUserDeatil = async (req, res, next) => {
  /* 	#swagger.tags = ['User']
      #swagger.description = 'Get users Detail'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
      #swagger.responses[200] = {
        schema:{
          "status": "success",
          "code": 200,
          "message": "",
          "data":  {
            "_id": "610bc1b31b82a66f6bcd64ea",
            "first_name": "akash",
            "last_name": "kumar",
            "email": "akash@gmail.com",
            "role": "admin",
            "__v": 0
          },
          "error": {}
        }
      }
  */
  let code, message;
  const _id = req.params.id;
  try {
    code = 200;
    const data = await userModel.findById({ _id });
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

const addUser = async (req, res, next) => {
  /* 	#swagger.tags = ['User']
      #swagger.description = 'Add new user'
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $first_name: 'Jhon',
            $last_name: 'Doe',
            $email: 'jhon@valuebound.com',
            $role: 'admin'
        }
      }
      #swagger.responses[201] = {
        description: 'User successfully added.',
        schema: { 
          "status": "success",
          "code": 201,
          "message": "",
          "data": {
            "first_name": 'Jhon',
            "last_name": 'Doe',
            "email": 'jhon@valuebound.com',
            "role": 'admin', 
          },
          "error": {}
        }
      }
  */
  let code, message;
  const { error } = addUserSchema.validate(req.body);
  if (error) {
    error.status = 422;
    next(error);
  }
  try {
    code = 201;
    const data = new userModel(req.body);
    await data.save();
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

const updateUser = async (req, res, next) => {
  /* 	#swagger.tags = ['User']
      #swagger.description = 'Update user'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $first_name: 'Jhon',
            $last_name: 'Doe',
            $email: 'jhon@valuebound.com',
            $role: 'admin'
        }
      }
      #swagger.responses[200] = {
        description: 'User successfully updated.',
        schema: { 
          "status": "success",
          "code": 200,
          "message": "",
          "data": {
            "first_name": 'Jhon',
            "last_name": 'Doe',
            "email": 'jhon@valuebound.com',
            "role": 'admin'
          },
          "error": {}
        }
      }
  */
  let code, message;
  const _id = req.params.id;
  try {
    code = 200;
    message = "user successfully updated!";
    const user = await userModel.findOneAndUpdate(
      { _id },
      { ...req.body },
      { new: true }
    );
    await user.save();
    const resData = customResponse({
      code,
      data: user,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

const deleteUser = async (req, res, next) => {
  /* 	#swagger.tags = ['User']
      #swagger.description = 'Delete user'
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.responses[200] = {
      schema:{
        "status": "success",
        "code": 200,
        "message": "User deleted successfully",
        "data":  {
          "_id": "610bc1b31b82a66f6bcd64ea",
          "first_name": 'Jhon',
          "last_name": 'Doe',
          "email": 'jhon@valuebound.com',
          "role": 'admin',
          "__v": 0
        },
        "error": {}
      }
    }
  */
  let code, message;
  const _id = req.params.id;
  try {
    code = 200;
    const user = await userModel.findByIdAndDelete({ _id });
    message = "user successfully deleted!";
    const resData = customResponse({
      code,
      data: user,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
const auth = async (req, res, next) => {
  /* 	#swagger.tags = ['User']
      #swagger.parameters['XAuthToken'] = {
        in: 'header',
        type: 'string',
        description: 'XAuthToken token provided by API Admin' 
      }
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $first_name: 'Jhon',
            $last_name: 'Doe',
            $email: 'jhon@valuebound.com',
            $role: 'admin'
        }
      }
      #swagger.responses[201] = {
        description: 'User successfully added.',
        schema: { 
          "status": "success",
          "code": 201,
          "message": "",
          "data": { 
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiSmhvbiBEb2UiLCJpYXQiOjE2Mjg0OTQ5NzksImV4cCI6MTYyODY2Nzc3OSwiaXNzIjoidmItY21zIn0.wdyX_wXWABr1BIw_7FzZKgowhixX8EXVN4ZojvzsaIU",
          },
          "error": {}
        }
      }
  */
  let code, message, data, reqBody;
  const { error } = addUserSchema.validate(req.body);
  if (error) {
    code = 422;
    message = "Invalid request data";
    const resData = customResponse({
      code,
      message,
      err: error && error.details,
    });
    return res.status(code).send(resData);
  }
  try {
    code = 200;
    if (req.body.token) {
      reqBody = req.body;
    } else {
      const payload = { ...req.body };
      const options = {
        expiresIn: process.env.EXPIRESIN,
        issuer: process.env.ISSUER,
      };
      const secret = process.env.JWT_SECRET;
      const token = jwt.sign(payload, secret, options);
      reqBody = { token, ...req.body };
    }

    const user = await userModel.findOne({ email: req.body.email }).exec();
    if (!user) {
      code = 201;

      data = new userModel(reqBody);
      await data.save();
    } else {
      code = 200;

      data = await userModel.findOneAndUpdate(
        { email: req.body.email },
        { ...reqBody },
        { new: true }
      );
      await data.save();
    }
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
const getAccount = async (req, res, next) => {
  /* 	#swagger.tags = ['User']
      #swagger.description = 'Get Account'
      #swagger.security = [{
               "apiKeyAuth": []
      }]
      #swagger.responses[200] = {
        schema: { 
          "status": "success",
          "code": 200,
          "message": "",
          "data": { 
            "first_name": 'Jhon',
            "last_name": 'Doe',
            "email": 'jhon@valuebound.com',
            "role": 'admin', 
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiSmhvbiBEb2UiLCJpYXQiOjE2Mjg0OTQ5NzksImV4cCI6MTYyODY2Nzc3OSwiaXNzIjoidmItY21zIn0.wdyX_wXWABr1BIw_7FzZKgowhixX8EXVN4ZojvzsaIU",
          },
          "error": {}
        }
      }
  */
  let code, message, data;
  const authorizationHeaader = req.headers.authorization.split(" ")[1];
  try {
    code = 200;
    const user = await userModel
      .findOne({ token: authorizationHeaader }).exec();
    const resData = customResponse({ code, data: user });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

/**
 * create urser group
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
const createUserGroup = async (req, res, next) => {
    /*#swagger.tags = ['UserGroup']
      #swagger.description = 'Create User Group'
      #swagger.security = [{
               "apiKeyAuth": []
      }]
      #swagger.responses[200] = {
        schema: { 
          "status": "success",
          "code": 200,
          "message": "User group has been created successfully."
        }
      }
  */

  try {
    code = 201;
    const data = new userGroupModel(req.body);
    await data.save();
    return res.status(code).send({success: true, message: "User group has been created successfully."});
  } catch (error) {
    next(error);
  }
}

/**
 * get urser group by ID
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
 const getUserGroupById = async (req, res, next) => {
  
  /*#swagger.tags = ['UserGroup']
      #swagger.description = 'Get User Group By Id'
      #swagger.security = [{
               "apiKeyAuth": []
      }]
      #swagger.responses[200] = {
        schema: { 
          "status": "success",
          "code": 200,
          "data": {
            _id: 100,
            group_name: "Super Admin Group",
            user_ids: [101,102,103,104]
          }
        }
      }
  */

  const _id = req.params.id;
  try {
    const data = await userGroupModel.findOne({_id })
    return res.status(200).send({success: true, data: data});
  } catch (error) {
    next(error);
  }
}

/**
 * Get All user groupd details
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
 const getUserGroupList = async (req, res, next) => {
  /*#swagger.tags = ['UserGroup']
      #swagger.description = 'Get User Group By Id'
      #swagger.security = [{
               "apiKeyAuth": []
      }]
      #swagger.responses[200] = {
        schema: { 
          "status": "success",
          "code": 200,
          "data": [{
            _id: 100,
            group_name: "Super Admin Group",
            user_ids: [101,102,103,104]
          }]
        }
      }
  */
  try {
    const data = await userGroupModel.find({})
    return res.status(200).send({success: true, data: data});
  } catch (error) {
    next(error);
  }
}

const userLogin = async (req, res) => {
  console.log("user sessions created");


}
module.exports = {
  getUserList,
  getUserDeatil,
  addUser,
  updateUser,
  deleteUser,
  auth,
  getAccount,
  createUserGroup,
  getUserGroupById,
  getUserGroupList,
  userLogin
};
