const puppeteer = require("puppeteer");
const constant = require("../utility/constant");

const generatePDF = async ({ reportId = "", url = "" }) => {
    let page_url;
    if (!url) {
        page_url = `${constant.API_URL}/index?report_id=${reportId}`;
        file_path = `public/static/pdf/${reportId}.pdf`;
        console.log("Generating PDF for report id: " + reportId);
    } else {
        page_url = url
        let formatted_url = new Buffer.from(url);
        let filename = formatted_url.toString('base64');
        file_path = `public/static/pdf/${filename}.pdf`;
        console.log("Generating PDF for report url: " + page_url);
    }

    const browser = await puppeteer.launch({
        headless: true,
        ignoreHTTPSErrors: true,
        args: ["--no-sandbox", "--disable-dev-shm-usage"],
        ignoreDefaultArgs: ['--disable-extensions'],
        slowMo: 250,
    });
    console.log("browser launched");
    const page = await browser.newPage();
    console.log("new page has been created");
    await page.goto(page_url, {
        waitUntil: 'networkidle2',
    });

    await page.addStyleTag({ content: 'div{page-break-inside: avoid} body{width: 992px; margin:0 auto;} .overlay-non-editable{display: none}' })
    console.log("page data has been fetched");
    // page.pdf() is currently supported only in headless mode.
    // @see https://bugs.chromium.org/p/chromium/issues/detail?id=753118
    await page.pdf({
        path: file_path,
        format: 'A4',
        printBackground: true,
        width: 992
    });
    console.log("pdf has been generated");

    await browser.close();
    return;
};
const generatePriviewImage = async (reportId, type) => {
    const browser = await puppeteer.launch({
        headless: true,
        ignoreHTTPSErrors: true,
        args: ["--no-sandbox", "--disable-dev-shm-usage"],
        ignoreDefaultArgs: ['--disable-extensions'],
        slowMo: 250,
    });
    const page = await browser.newPage();
    await page.goto(`${constant.API_URL}/index?report_id=${reportId}&type=${type}`, {
        'waitUntil': 'networkidle2'
    });
    await page.setViewport({ width: 1200, height: 800 });
    await page.screenshot({
        path: `public/static/screenshot/${type}/${reportId}.jpeg`,
        type: "jpeg",
        printBackground: true
    });
    await page.close();
    await browser.close();
    return;
};

module.exports = { generatePriviewImage, generatePDF };
