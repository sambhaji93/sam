const { NotificationModel } = require('../models/notification')


const Notifications = async (req, res, next) => {
    /* #swagger.tags = ['Notification']
      #swagger.description = 'Get All notification list'
      #swagger.security = [{
          "apiKeyAuth": []
      }]
    */
    const params = req.query
    try {
        const notificationDetails = await NotificationModel.find(params)
        return res.status(200).send({success: true, data: notificationDetails})
    } catch (error) {
        next(error);
    }

}

module.exports = {
    Notifications
}