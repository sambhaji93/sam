const { customResponse, customPagination } = require("../utility/helper");
const { reportModel } = require("../models/report");
const { userModel } = require("../models/user");

const getNavMetaInfo = async (req, res, next) => {
  /* #swagger.tags = ['Reports']
      #swagger.description = 'Get reports list'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
  */
  const menuList = [
    {
      name: "Reports",
      to: "/",
      icon: "<AiFillSignal />",
    },
    {
      name: "Templates",
      to: "/templates",
      icon: "<FaFolder />",
    },
    {
      name: "Media",
      to: "/media",
      icon: "<MdPermMedia />",
    },
    {
      name: "Settings",
      to: "/settings",
      icon: "<RiSettings3Fill />",
    },
    {
      name: "Email Template",
      to: "/email-template",
      icon: "<MdEmail />",
    }
  ];
  try {
    code = 200;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const user = await userModel
      .findOne(
        { token: authorizationHeaader },
        { _id: 1, first_name: 1, last_name: 1, role: 1 }
      )
      .exec();
    const approvedReports = await reportModel
      .countDocuments({
        $and: [{ author: user._id }, { stage: "approved" }],
      })
      .exec();

    const totalReports = await reportModel.countDocuments({
      $and: [{ author: user._id }],
    })
      .exec();

    const data = {
      user,
      reports: {
        total: totalReports,
        approved: approvedReports,
      },
      menu: menuList,
    };
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

module.exports = { getNavMetaInfo };
