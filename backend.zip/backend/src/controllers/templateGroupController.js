const { customResponse, customPagination } = require("../utility/helper");
const templateGroupModel = require("../models/templateGroup");
const { getCurrentUsersDetails } = require("../utility/helper");

const getTemalteGroups = async (req, res, next) => {
    /* 	#swagger.tags = ['Template Group']
        #swagger.description = 'Get Template Group list'
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
        #swagger.parameters['page'] = {
          in: 'query',
          type: 'integer',
          description: 'Page number' 
        }
        #swagger.parameters['limit'] = {
          in: 'query',
          type: 'integer',
          description: 'Data limit per page' 
        }
        #swagger.parameters['start_date'] = {
          in: 'query',
          type: 'Date',
        }
        #swagger.parameters['end_date'] = {
          in: 'query',
          type: 'Date',
        }
        #swagger.parameters['title'] = {
          in: 'query',
          type: 'string'
        }
        #swagger.parameters['sort_by'] = {
          in: 'query',
          type: 'string',
          description: 'Ex created_at_asc , created_at_desc, updated_at_asc,updated_at_desc, title_asc, title_desc'
        }
    */
    let code;
    let todayDate = new Date();
    let startDate = new Date();
    startDate.setDate(startDate.getDate() - 365);
    const page = req.query.page ? req.query.page : 1;
    const limit = req.query.limit ? req.query.limit : 100;
    const start_date = req.query.start_date
        ? new Date(req.query.start_date)
        : startDate;
    let end_date = req.query.end_date ? new Date(req.query.end_date) : todayDate;
    end_date.setDate(end_date.getDate() + 1);
    const searchString = [
        {
            name: { $regex: "" },
        },
    ];
    if (req.query.sort_by)
        if (req.query.name) {
            searchString.push({
                name: { $regex: new RegExp(req.query.name, "i") },
            });
        }

    try {
        code = 200;
        const templateGroupData = await templateGroupModel.find(
            {
                created_at: {
                    $gte: start_date,
                    $lte: end_date,
                },
                $and: [{ $and: searchString }],
            }
        ).populate("updated_by", "_id first_name last_name");

        const data = customPagination({ data: templateGroupData, page, limit });
        const resData = customResponse({ code, data });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};

/**
 * Function that list and search temaplates.
 */
const templateGroupDetail = async (req, res, next) => {
    /* 	#swagger.tags = ['Template Group']
        #swagger.description = 'Get Template Group Detail'
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
    */
    let code;
    const _id = req.params.id;
    try {
        code = 200;
        const data = await templateGroupModel.findById({ _id });
        if (!data) {
            next({ status: 404, message: "Not found with id " + _id });
        }
        const resData = customResponse({ code, data });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const storeTemplateGroup = async (req, res, next) => {
    /* 	#swagger.tags = ['Template Group']
        #swagger.description = 'Store new Template Group '
        #swagger.security = [{
            "apiKeyAuth": []
        }] 
        #swagger.parameters['obj'] = {
          in: 'body',
          schema: {
               $name: 'test',
               $description: 'Lorem Ipsum is simply dummy text of the',
          }
        }
    */
    try {
        let code = 201;
        const authorizationHeaader = req.headers.authorization.split(" ")[1];
        const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
        req.body.created_by = currentUserDetails._id;
        const data = new templateGroupModel(req.body);
        await data.save();
        const resData = customResponse({ code, data });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const updateTemplateGroup = async (req, res, next) => {
    /* 	#swagger.tags = ['Template Group']
        #swagger.description = 'Update Template Group ' 
        #swagger.security = [{
            "apiKeyAuth": []
        }] 
        #swagger.parameters['obj'] = {
          in: 'body',
          schema: {
              $name: 'test',
              $description: 'Lorem Ipsum is simply dummy text of the',
          }
        }
    */
    let code, message;
    const _id = req.params.id;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.updated_by = currentUserDetails._id;
    try {
        code = 200;
        message = "Successfully updated!";
        const data = await templateGroupModel.findOneAndUpdate(
            { _id },
            { ...req.body },
            { new: true }
        );
        if (!data) {
            code = 404;
            message = "Not Found";
            const resData = customResponse({
                code,
                message,
                err: {},
            });
            return res.status(code).send(resData);
        }
        await data.save();
        const resData = customResponse({
            code,
            data,
            message,
        });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const destoryTemplateGroup = async (req, res, next) => {
    /* 	#swagger.tags = ['Template Group']
        #swagger.description = 'Delete Template Group '
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
    */
    let code, message;
    const _id = req.params.id;
    try {
        code = 200;
        const data = await templateGroupModel.findByIdAndDelete({ _id });
        if (!data) {
            code = 404;
            message = "Not Found";
            const resData = customResponse({
                code,
                message,
                err: {},
            });
            return res.status(code).send(resData);
        }
        message = "Successfully deleted!";
        const resData = customResponse({
            code,
            data,
            message,
        });
        return res.status(code).send(resData);
    } catch (error) {
        next(error);
    }
};

module.exports = {
    getTemalteGroups,
    templateGroupDetail,
    storeTemplateGroup,
    updateTemplateGroup,
    destoryTemplateGroup,
};
