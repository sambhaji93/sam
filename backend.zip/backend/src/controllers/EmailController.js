const { customResponse, customPagination } = require("../utility/helper");
const { findEmails, findEmailDetail, saveEmail, updateEmailData, deleteEmail } = require("../services/emailService");
const { getCurrentUsersDetails } = require("../utility/helper");
const getEmails = async (req, res, next) => {
  /* #swagger.tags = ['Emails']
      #swagger.description = 'Get emails list'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
      #swagger.parameters['page'] = {
        in: 'query',
        type: 'integer',
        description: 'Page number' 
      }
      #swagger.parameters['limit'] = {
        in: 'query',
        type: 'integer',
        description: 'Data limit per page' 
      }
      #swagger.parameters['title'] = {
        in: 'query',
        type: 'string',
        description: 'email title string' 
      }
      #swagger.parameters['category'] = {
        in: 'query',
        type: 'string',
        description: 'email category string' 
      }
      #swagger.parameters['status'] = {
        in: 'query',
        type: 'string',
        description: 'email status string'
      }
  */
  let code, sortBy;
  let todayDate = new Date();
  let defaultStartDate = new Date();
  defaultStartDate.setDate(defaultStartDate.getDate() - 365);
  const page = req.query.page ? req.query.page : 1;
  const limit = req.query.limit ? req.query.limit : 15;
  const startDate = req.query.start_date
    ? new Date(req.query.start_date)
    : defaultStartDate;
  let endDate = req.query.end_date ? new Date(req.query.end_date) : todayDate;
  endDate.setDate(endDate.getDate() + 1);
  const searchString = [
    {
      title: { $regex: "" },
    },
  ];
  if (req.query.title) {
    searchString.push({
      title: { $regex: new RegExp(req.query.status, "i") },
    });
  }
  if (req.query.category) {
    searchString.push({
      stage: req.query.category,
    });
  }
  if (req.query.status) {
    searchString.push({
      status: req.query.status
    });
  }
  switch (req.query.sort_by) {
    case "created_at_asc":
      sortBy = { created_at: 1 };
      break;
    case "created_at_desc":
      sortBy = { created_at: -1 };
      break;
    case "updated_at_asc":
      sortBy = { updated_at: 1 };
      break;
    case "updated_at_desc":
      sortBy = { updated_at: -1 };
      break;
    case "title_asc":
      sortBy = { title: 1 };
      break;
    case "title_desc":
      sortBy = { title: -1 };
      break;
    default:
      sortBy = { created_at: 1 };
      break;
  }

  try {
    code = 200;
    const emailData = await findEmails(searchString, startDate, endDate, sortBy)
    const data = customPagination({ data: emailData, page, limit });
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 * Function that list and search emails.
 */
const emailDetail = async (req, res, next) => {
  /* 	#swagger.tags = ['email']
      #swagger.description = 'Get email Detail'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
  */
  let code;
  const _id = req.params.id;
  try {
    code = 200;
    const data = await findEmailDetail(_id);
    if (!data) {
      next({ status: 404, message: "Not found with id " + _id });
    }
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const storeEmail = async (req, res, next) => {
  /* 	#swagger.tags = ['Email']
      #swagger.description = 'Store new Email'
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $title: 'email title string',
            $category : 'email category string',
            $tag : 'email tag string',
            $html : 'email html string',
            $attachments: 'email attachments string URL',
            $status : 'draft',
        }
      }
  */
  let code;
  try {
    code = 201;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.created_by = currentUserDetails._id;
    const data = await saveEmail(req.body);
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const updateEmail = async (req, res, next) => {
  /* 	#swagger.tags = ['Email']
      #swagger.description = 'Update Email' 
      #swagger.security = [{
          "apiKeyAuth": []
      }]
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $title: 'email title string',
            $category : 'email category string',
            $tag : 'email tag string',
            $html : 'email html string',
            $attachments: 'email attachments string URL',
            $status : 'draft',
        }
      } 
  */
  let code, message;
  const _id = req.params.id;
  try {
    code = 200;
    message = "successfully updated!";
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.updated_by = currentUserDetails._id;

    const data = await updateEmailData(_id, req.body);
    if (!data) {
      code = 404;
      message = "Not Found";
      const resData = customResponse({
        code,
        message,
        err: {},
      });
      return res.status(code).send(resData);
    }
    const resData = customResponse({
      code,
      data,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const destoryEmail = async (req, res, next) => {
  /* 	#swagger.tags = ['Email']
      #swagger.description = 'Delete Email'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
  */
  let code, message;
  const _id = req.params.id;
  try {
    code = 200;
    const data = await deleteEmail(_id);
    if (!data) {
      code = 404;
      message = "Not Found";
      const resData = customResponse({
        code,
        message,
        err: {},
      });
      return res.status(code).send(resData);
    }
    message = "successfully deleted!";
    const resData = customResponse({
      code,
      data,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getEmails,
  emailDetail,
  storeEmail,
  updateEmail,
  destoryEmail,
};
