const { customResponse, customPagination } = require("../utility/helper");
const commentModel = require("../models/comment");
const { userModel } = require("../models/user");
const { saveNotification } = require("./../services/notificationService");
const { reportModel } = require("../models/report");
const { getCurrentUsersDetails } = require("./../utility/helper");

const getComment = async (req, res, next) => {
  /* #swagger.tags = ['Comment']
        #swagger.description = 'Get Comment list'
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
        #swagger.parameters['page'] = {
          in: 'query',
          type: 'integer',
          description: 'Page number' 
        }
        #swagger.parameters['limit'] = {
          in: 'query',
          type: 'integer',
          description: 'Data limit per page' 
        }
        #swagger.parameters['message'] = {
          in: 'query',
          type: 'string'
        }
        #swagger.parameters['report_id'] = {
          in: 'query',
          type: 'string'
        }
        #swagger.parameters['is_child'] = {
          in: 'query',
          type: 'Boolean'
        }
    */
  const page = req.query.page ? req.query.page : 1;
  const limit = req.query.limit ? req.query.limit : 15;
  const searchString = [
    {
      message: { $regex: "" },
    },
    {
      is_child: false,
    },
  ];

  if (req.query.text) {
    searchString.push({
      message: { $regex: new RegExp(req.query.text, "i") },
    });
  }
  if (req.query.report_id) {
    searchString.push({
      report_id: req.query.report_id,
    });
  }
  try {
    code = 200;
    const CommentData = await commentModel
      .find({
        $and: [{ $and: searchString }],
      })
      .sort({ created_at: 1 })
      .populate("sender_id", "_id first_name last_name")
      .populate("updated_by", "_id first_name last_name")
      .populate({
        path: "reply",
        populate: {
          path: "sender_id",
          model: "User",
        },
      });
    const data = customPagination({ data: CommentData, page, limit });
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

const commentDetail = async (req, res, next) => {
  /*  #swagger.tags = ['Comment']
        #swagger.description = 'Get Comment Detail'
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
    */
  let code;
  const _id = req.params.id;
  try {
    code = 200;
    const data = await commentModel
      .findById({ _id })
      .populate("sender_id", "_id first_name last_name");
    if (!data) {
      next({ status: 404, message: "Not found with id " + _id });
    }
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const storeComment = async (req, res, next) => {
  /* 	#swagger.tags = ['Comment']
        #swagger.description = 'Store new Comment'
        #swagger.security = [{
            "apiKeyAuth": []
        }] 
        #swagger.parameters['obj'] = {
          in: 'body',
          schema: {
              $message: 'some text goes here',
              $report_id : '616ef2808a7eef2171ef5c5e',
              $sender_id : '616ceec4ddee4107048753da',
              $tagged_users : ['616ceec4ddee4107048753da'],
              $offsetx : 1200,
              $offsety:900,
          }
        }
    */
  let code;
  try {
    code = 201;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.created_by = currentUserDetails._id;
    req.body.sender_id = [currentUserDetails._id];
    const data = new commentModel(req.body);
    await data.save();
    const reportDetails = await reportModel.findById(req.body.report_id);
    const message = `${currentUserDetails.first_name} has tagged you in comments in this report ${reportDetails.title}.`
    const taggedUsers = req.body.tagged_users;
    taggedUsers.forEach((userId) => {
      saveNotification(req, "reports", "commented", message, req.body.report_id, userId);
    });
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const updateComment = async (req, res, next) => {
  /* 	#swagger.tags = ['Comment']
        #swagger.description = 'Update Comment' 
        #swagger.security = [{
            "apiKeyAuth": []
        }]
        #swagger.parameters['obj'] = {
          in: 'body',
          schema: {
              $message: 'some text goes here',
              $report_id : '616ef2808a7eef2171ef5c5e',
              $sender_id : '616ceec4ddee4107048753da',
              $tagged_users : ['616ceec4ddee4107048753da'],
              $offsetx : 1200,
              $offsety:900,
              $is_child : false,
              $reply : ["61975142cbc48ca06cdb9ca5"]
          }
        } 
    */
  let code, message;
  const _id = req.params.id;
  try {
    code = 200;
    message = "successfully updated!";
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.updated_by = currentUserDetails._id;
    const data = await commentModel.findOneAndUpdate(
      { _id },
      { ...req.body },
      { new: true }
    );
    if (!data) {
      code = 404;
      message = "Not Found";
      const resData = customResponse({
        code,
        message,
        err: {},
      });
      return res.status(code).send(resData);
    }
    await data.save();
    const resData = customResponse({
      code,
      data,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const destoryComment = async (req, res, next) => {
  /* 	#swagger.tags = ['Comment']
        #swagger.description = 'Delete Comment'
        #swagger.security = [{
            "apiKeyAuth": []
        }]  
    */
  let code, message;
  const _id = req.params.id;
  try {
    code = 200;
    const data = await commentModel.findByIdAndDelete({ _id });
    if (!data) {
      code = 404;
      message = "Not Found";
      const resData = customResponse({
        code,
        message,
        err: {},
      });
      return res.status(code).send(resData);
    }
    message = "successfully deleted!";
    const resData = customResponse({
      code,
      data,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getComment,
  commentDetail,
  storeComment,
  updateComment,
  destoryComment,
};