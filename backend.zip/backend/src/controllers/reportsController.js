const { customResponse, customPagination } = require("../utility/helper");
const { reportModel, reportVerionsModel } = require("../models/report");
const { userModel } = require("../models/user");
const sendMail = require("./../utility/smtp");
const { saveNotification } = require("./../services/notificationService");
const {
  colaboratedEditingService,
  sectionLockingService,
} = require("./../services/reportService");
const {
  getWorkFlow,
  updateWorkFlow,
} = require("./../services/workflowService");
const groupArray = require("group-array");
const {
  generatePriviewImage,
  generatePDF,
} = require("../controllers/generate");
const constant = require("../utility/constant");
const { getCurrentUsersDetails } = require("../utility/helper");
const fs = require("fs");

const getReports = async (req, res, next) => {
  /* #swagger.tags = ['Reports']
      #swagger.description = 'Get reports list'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
      #swagger.parameters['page'] = {
        in: 'query',
        type: 'integer',
        description: 'Page number' 
      }
      #swagger.parameters['limit'] = {
        in: 'query',
        type: 'integer',
        description: 'Data limit per page' 
      }
      #swagger.parameters['author'] = {
        in: 'query',
        type: 'string',
        description: 'Author user ID' 
      }
      #swagger.parameters['stage'] = {
        in: 'query',
        type: 'string',
        description: 'stage such as draft, waiting_for_approval, approved' 
      }
      #swagger.parameters['start_date'] = {
        in: 'query',
        type: 'Date',
      }
      #swagger.parameters['end_date'] = {
        in: 'query',
        type: 'Date',
      }
      #swagger.parameters['title'] = {
        in: 'query',
        type: 'string'
      }
      #swagger.parameters['sort_by'] = {
        in: 'query',
        type: 'string',
        description: 'Ex created_at_asc , created_at_desc, updated_at_asc,updated_at_desc, title_asc, title_desc'
      }
  */
  let code, sort_by;
  let todayDate = new Date();
  let startDate = new Date();
  const authorizationHeaader = req.headers.authorization.split(" ")[1];
  const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
  const currentUserId = currentUserDetails._id;
  startDate.setDate(startDate.getDate() - 365);
  const page = req.query.page ? req.query.page : 1;
  const limit = req.query.limit ? req.query.limit : 15;
  const start_date = req.query.start_date
    ? new Date(req.query.start_date)
    : startDate;
  let end_date = req.query.end_date ? new Date(req.query.end_date) : todayDate;
  end_date.setDate(end_date.getDate() + 1);
  const searchString = [
    {
      title: { $regex: "" },
    },
  ];
  if (req.query.author) {
    searchString.push({
      author: req.query.author,
    });
  }
  if (req.query.stage) {
    searchString.push({
      stage: req.query.stage,
    });
  }
  if (req.query.title) {
    searchString.push({
      title: { $regex: new RegExp(req.query.title, "i") },
    });
  }
  switch (req.query.sort_by) {
    case "created_at_asc":
      sort_by = { created_at: 1 };
      break;
    case "created_at_desc":
      sort_by = { created_at: -1 };
      break;
    case "updated_at_asc":
      sort_by = { updated_at: 1 };
      break;
    case "updated_at_desc":
      sort_by = { updated_at: -1 };
      break;
    case "title_asc":
      sort_by = { title: 1 };
      break;
    case "title_desc":
      sort_by = { title: -1 };
      break;
    default:
      sort_by = { created_at: 1 };
      break;
  }
  try {
    code = 200;
    const reportData = await reportModel
      .find(
        {
          created_at: {
            $gte: start_date,
            $lte: end_date,
          },
          $and: [{
            $and: searchString,
            $and: [
              {
                $or: [
                  { author: currentUserId },
                  { reviewers: currentUserId },
                  { contributors: currentUserId },
                ]
              },
            ]
          },
          ]
        },
        {
          title: 1,
          stage: 1,
          thumbnail: 1,
          created_at: 1,
          updated_at: 1,
          author: 1,
        },
        { sort: { ...sort_by } }
      )
      .sort({ created_at: -1 })
      .populate("author", "_id first_name last_name email role")
      .populate("updated_by", "_id first_name last_name");
    const data = customPagination({ data: reportData, page, limit });
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
const getAuthors = async (req, res, next) => {
  let code;
  code = 200;
  const reportData = await reportModel.find({}, { author: 1 });
  const author = [];

  for (let i = 0; i < reportData.length; i++) {
    author.push(reportData[i].author);
  }
  const authors = await userModel.find(
    { _id: { $in: author } },
    {
      _id: 1,
      first_name: 1,
      last_name: 1,
      email: 1,
    }
  );
  return res.status(code).send(authors);
};
const getApprovers = async (req, res, next) => {
  let code;
  code = 200;

  const authors = await userModel.find(
    { role: "approver" },
    {
      _id: 1,
      first_name: 1,
      last_name: 1,
      email: 1,
    }
  );
  return res.status(code).send(authors);
};
/**
 * Get Report stage
 */
const getStage = async (req, res, next) => {
  let code;
  code = 200;
  const reportData = await reportModel.distinct("stage");
  return res.status(code).send(reportData);
};
/**
 * Function that list and search temaplates.
 */
const reportDetail = async (req, res, next) => {
  /*  #swagger.tags = ['Reports']
      #swagger.description = 'Get report Detail'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
  */
  let code;
  const _id = req.params.id;
  try {
    code = 200;
    const data = await reportModel
      .findById({ _id })
      .populate("author", "_id first_name last_name email role")
      .populate("contributors", "_id first_name last_name email");
    if (!data) {
      next({ status: 404, message: "Not found with id " + _id });
    }
    return res.status(code).send(data);
  } catch (error) {
    next(error);
  }
};

/**
 * Check whether auther is admin or not
 * @param {*} authorId
 * @returns
 */
const checkAutherStatus = async (authorId) => {
  const autherDetails = await userModel.findById(authorId);
  if (autherDetails.role == "admin") {
    return true;
  }
  return false;
};

/**
 *
 * @param {*} req
 * @param {*} res
 */
const storeReport = async (req, res, next) => {
  /* 	#swagger.tags = ['Reports']
      #swagger.description = 'Store new reports'
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $title: 'test',
            $comments: [
              {
                user: {
                  first_name : "Amit",
                  last_name : "kumar",
                  email : "amit@gmail.com",
                  role : "admin",
                },
                text: "some text",
                offsetx: 500,
                offsety: 250,
              }
            ],
            $sections: [],
            $stage: 'waiting_for_approval',
            $report_settings : {}
        }
      }
  */
  let code;
  try {
    code = 200;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.author = [currentUserDetails._id];
    req.body.created_by = currentUserDetails._id;
    req.body.thumbnail = `${constant.API_URL}/static/screenshot/reports/gjs_default_placeholder.jpg`;
    const data = new reportModel(req.body);
    await data.save();
    await createReportsVeriosn(data, "patch", "new", currentUserDetails._id, "");

    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

/**
 * Report workflow
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
const getReportWorkflow = async (req, res, next) => {
  const payload = req.body;
  const reportId = req.params.id;

  try {
    const results = await getWorkFlow(req, reportId, payload);

    return res.status(200).send(results);
  } catch (error) {
    next(error);
  }
};

/**
 * Update reports and send data to drupal
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
const updateReportWorkflow = async (req, res, next) => {
  const payload = req.body;
  const reportId = req.params.id;
  try {
    const results = await updateWorkFlow(req, reportId, payload);
    return res.status(200).send(results);
  } catch (error) {
    next(error);
  }
};

/**
 *
 * @param {*} req
 * @param {*} res
 */
const updateReport = async (req, res, next) => {
  /* 	#swagger.tags = ['Reports']
      #swagger.description = 'Update report' 
      #swagger.security = [{
          "apiKeyAuth": []
      }]
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $title: 'test',
            $comments: [
              {
                user: {
                  first_name : "Amit",
                  last_name : "kumar",
                  email : "amit@gmail.com",
                  role : "admin",
                },
                text: "some text",
                offsetx: 500,
                offsety: 250,
              }
            ],
            $sections: [],
            $stage: 'waiting_for_approval',
            $report_settings : {}
        }
      } 
  */
  let code, message;
  const _id = req.params.id;
  const authorizationHeaader = req.headers.authorization.split(" ")[1];
  const user = await userModel.findOne({ token: authorizationHeaader }).exec();
  try {
    code = 200;
    message = "successfully updated!";
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    req.body.updated_by = currentUserDetails._id;

    const data = await reportModel.findOneAndUpdate(
      { _id },
      { ...req.body },
      { new: true }
    );
    if (!data) {
      code = 404;
      message = "Not Found";
      const resData = customResponse({
        code,
        message,
        err: {},
      });
      return res.status(code).send(resData);
    }
    await data.save();
    // await createReportsVeriosn(data, 'patch', 'update', user._id, "");

    if (req.body.stage == "approved") {
      await createReportsVeriosn(data, "major", "update", user._id, "");
    } else if (req.body.stage) {
      await createReportsVeriosn(data, "minor", "update", user._id, "");
    }
    const resData = customResponse({
      code,
      data,
      message,
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
/**
 *
 * @param {*} req
 * @param {*} res
 */
const destoryReport = async (req, res, next) => {
  /* 	#swagger.tags = ['Reports']
      #swagger.description = 'Delete report'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
  */
  let code, message;
  const _id = req.params.id;
  let reviewers = [];
  try {
    code = 200;
    const data = await reportModel.findByIdAndDelete({ _id });
    if (!data) {
      code = 404;
      message = "Not Found";
      const resData = customResponse({
        code,
        message,
        err: {},
      });
      return res.status(code).send(resData);
    }
    reviewers = data.reviewers;
    reviewers.push(data.author);
    message = "successfully deleted!";
    const resData = customResponse({
      code,
      data,
      message,
    });
    reviewers.forEach((userId) => {
      saveNotification(req, "reports", "deleted", "", _id, userId);
    });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};

/**
 * This function simply send email to the auther about the status of reports
 * @param {*} authorId Report authorId
 * @param {*} status Report status
 */

const sendMailToAuther = async (authorId, status) => {
  const autherDetails = await userModel.findById(authorId);
  const options = {
    to: autherDetails.email,
    subject: "Report status",
  };
  if (status === "publish") {
    options.text = `
    Hi ${autherDetails.first_name} ${autherDetails.last_name},
    Your report has been publish`;
  } else if (status === "reject") {
    options.text = `
    Hi ${autherDetails.first_name} ${autherDetails.last_name},
    Your report has been publish`;
  }
  sendMail(options);
};

/**
 * This function method just allow admin to approved or reject reports
 * @param {report id or reports comments details} req
 * @param {Publish or Reject status} res
 * @param {*} next
 * @returns
 */
const approveRejectReport = async (req, res, next) => {
  /* 	#swagger.tags = ['Reports']
      #swagger.description = 'Store new reports'
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $status: 'publish',
            $comments: [
              {
                  "user": {
                      "first_name": "Amit",
                      "last_name": "kumar",
                      "email": "amit313e1qeq1@gmail.com",
                      "role": "admin"
                  },
                  "text": "some text",
                  "offsetx": 500,
                  "offsety": 250
              }
            ]
        }
      }
  */
  const reportId = req.params.id;
  const status = req.body.status;
  const comments = req.body.comments;
  let message;
  try {
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const user = await userModel
      .findOne({ token: authorizationHeaader })
      .exec();
    const reportDetails = await reportModel.find({ _id: reportId });

    if (status === "publish" && reportDetails.length > 0) {
      await reportModel.updateOne(
        { _id: reportId },
        {
          isPublish: true,
          $push: { comments: comments },
          stage: "waiting_for_approval",
        }
      );
      message = "Report Publish successfully";
      await createReportsVeriosn(data, "major", "update", user._id, "");
    } else if (status === "reject" && reportDetails.length > 0) {
      await reportModel.updateOne(
        { _id: reportId },
        { isPublish: true, $push: { comments: comments }, stage: "rejected" }
      );
      await createReportsVeriosn(data, "minor", "update", user._id, "");
      message = "Report Rejected";
    } else {
      return res
        .status(422)
        .send({ success: true, message: "Report not found" });
    }
  } catch (error) {
    return res.status(500).send(error.message);
  }
  // Notify Auther about the status of the reports
  sendMailToAuther(reportDetails.auther, status);
  return res.status(200).send({ success: true, message });
};

/**
 * This function will just clone an existing report
 * @param {*} req
 * @param {*} res
 * @param {*} next
 * @returns
 */
const cloneReport = async (req, res, next) => {
  /* 	#swagger.tags = ['Reports']
      #swagger.description = 'Store new reports'
      #swagger.security = [{
          "apiKeyAuth": []
      }] 
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $title: 'test',
            $report_id : "615ad4c793a9c76d083fff19"
        }
      }
  */
  let code;
  try {
    const _id = req.body.report_id;
    code = 200;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const user = await userModel
      .findOne({ token: authorizationHeaader })
      .exec();
    const objectToCopy = await reportModel.findById({ _id });
    var reportData = JSON.parse(JSON.stringify(objectToCopy));
    delete reportData["_id"];
    delete reportData["created_at"];
    delete reportData["updated_at"];
    reportData["stage"] = "draft";
    reportData["author"] = user._id;
    reportData["title"] = req.body.title || `Copy of ${reportData.title}`;
    const data = new reportModel({ ...reportData });
    await data.save();
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
function formatDate(date) {
  var d = new Date(date),
    month = "" + (d.getMonth() + 1),
    day = "" + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = "0" + month;
  if (day.length < 2) day = "0" + day;

  return [year, month, day - 1].join("-");
}

const getHistory = async (req, res, next) => {
  try {
    const _id = req.params.id;
    code = 200;
    // const reportData = await reportVerionsModel.find({ report_id: _id }, {}, { sort: { 'created_at': -1 } });
    const reportData = await reportVerionsModel
      .find({ report_id: _id }, {}, { sort: { created_at: -1 }, limit: 50 })
      .populate("author");
    const updatedRep = reportData.map((report) => {
      const createdAt = formatDate(report.created_at);
      const monthNo = createdAt.split("-");
      var months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
      ];
      var month_index = parseInt(monthNo[1], 10) - 1;
      const month = months[month_index];
      const date = formatDate(report.created_at);
      return { ...report._doc, date, month };
    });
    const data = await groupArray(updatedRep, "month", "date");
    res.send(data);
  } catch (error) {
    next(error);
  }
};
const createNamedVersion = async (req, res, next) => {
  /*  #swagger.tags = ['Reports']
        #swagger.description = 'Get Report By Version'
        #swagger.security = [{
            "apiKeyAuth": []
        }] 
        #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $version_name: 'test'
        }
      } 
    */
  let code;
  try {
    const _id = req.params.reportId;
    const version_name = req.body.version_name || "";
    code = 200;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const user = await userModel
      .findOne({ token: authorizationHeaader })
      .exec();
    const data = await reportModel.findOneAndUpdate(
      { _id },
      {
        thumbnail: `${constant.API_URL}/static/screenshot/reports/${_id}.jpeg`,
      },
      { new: true }
    );
    await data.save();
    await createReportsVeriosn(data, "major", "update", user._id, version_name);
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
const restoreFromVersion = async (req, res, next) => {
  /*  #swagger.tags = ['Reports']
        #swagger.description = 'Get Report By Version'
        #swagger.security = [{
            "apiKeyAuth": []
        }]
        #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $version_name: 'test'
        }
      }  
    */
  let code;
  try {
    const reportId = req.params.reportId;
    const versionId = req.params.versionId;
    const thumbnail = `${constant.API_URL}/static/screenshot/reports/${reportId}.jpeg`;
    code = 200;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const user = await userModel
      .findOne({ token: authorizationHeaader })
      .exec();
    const reportVerionsData = await reportVerionsModel
      .findOne({ _id: versionId })
      .exec();

    const version_name =
      req.body.version_name ||
      `restored from ${reportVerionsData.version_name}`;
    const data = await reportModel.findOneAndUpdate(
      { _id: reportId },
      {
        ...reportVerionsData.report,
        thumbnail,
      },
      { new: true }
    );
    await createReportsVeriosn(data, "major", "update", user._id, version_name);
    const resData = customResponse({ code, data });
    return res.status(code).send(resData);
  } catch (error) {
    next(error);
  }
};
const getReportByVersion = async (req, res, next) => {
  /*  #swagger.tags = ['Reports']
      #swagger.description = 'Get Report By Version'
      #swagger.security = [{
          "apiKeyAuth": []
      }]  
  */
  const _id = req.params.versionId;
  code = 200;
  try {
    code = 200;
    const data = await reportVerionsModel.findById({ _id }).populate("author");
    if (!data) {
      next({ status: 404, message: "Not found with id " + _id });
    }
    return res.status(code).send(data);
  } catch (error) {
    next(error);
  }
};
/**
 * This function will just emit and event for colaborated editing
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
const colaboratedEditing = async (req, res, next) => {
  /* 	#swagger.tags = ['Reports']
      #swagger.description = 'Colaborated Editing'
      #swagger.security = [{
          "apiKeyAuth": []
      }]
      #swagger.parameters['obj'] = {
        in: 'body',
        schema: {
            $text: "Someone editing reports"
        },
        in: 'params', 
        schema: {
            $report_id : "615ad4c793a9c76d083fff19"
        },
      }
  */
  try {
    const _id = req.params.id;
    const response = await colaboratedEditingService(_id, req);
    res.status(200).send({ success: true, data: response });
  } catch (error) {
    next(error);
  }
};

/**
 * This function will just create an section lcoking events
 * @param {*} req
 * @param {*} res
 * @param {*} next
 */
const sectionLocking = async (req, res, next) => {
  /* 	#swagger.tags = ['Reports']
      #swagger.description = 'Section Locking'
      #swagger.security = [{
          "apiKeyAuth": []
      }]
      #swagger.parameters['obj'] = {
        in: 'params', 
        schema: {
            $cc_id : "615ad4c793a9c76d083fff19"
        },
      }
  */
  try {
    const _id = req.params.id;
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const user = await getCurrentUsersDetails(authorizationHeaader);
    const reportData = await reportModel.findById({ _id }).exec();
    const activeUsers = reportData.active_author;
    const currentUserIndex = activeUsers
      .map((e) => e.user_id)
      .indexOf(user._id);

    if (req.body.status == "lock") {
      if (activeUsers && currentUserIndex == -1) {
        activeUsers.push({
          user_id: user._id,
          first_name: user.first_name,
          last_name: user.last_name,
          ccid: req.body.ccid,
        });
      } else {
        activeUsers[currentUserIndex].ccid = req.body.ccid;
      }
    } else {
      activeUsers.splice(currentUserIndex, 1);
    }

    const updatereports = await reportModel.findOneAndUpdate(
      {
        _id,
      },
      {
        active_author: activeUsers,
      }
    );
    await updatereports.save();
    req.body.active_author = activeUsers;
    const response = await sectionLockingService(_id, req);
    res.status(200).send({ success: true, data: response });
  } catch (error) {
    next(error);
  }
};

function formatDate(date) {
  var d = new Date(date),
    month = "" + (d.getMonth() + 1),
    day = "" + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = "0" + month;
  if (day.length < 2) day = "0" + day;

  return [year, month, day].join("-");
}
const createReportsVeriosn = async (
  data,
  type,
  action,
  authorId,
  name = ""
) => {
  let version = "0.0.0";
  if (action == "update") {
    const lastReport = await reportVerionsModel.findOne(
      { report_id: data._id },
      {},
      { sort: { created_at: -1 } }
    );
    if (lastReport) {
      version = lastReport.version;
    }
  }

  let versions = version.split(".");
  let major_version = parseInt(versions[0]);
  let minor_version = parseInt(versions[1]);
  let patch_version = parseInt(versions[2]);

  switch (type) {
    case "major":
      major_version = major_version + 1;
      minor_version = 0;
      patch_version = 0;
      break;
    case "minor":
      minor_version = minor_version + 1;
      patch_version = 0;
      break;
    default:
      patch_version = patch_version + 1;
  }
  const latestVersion = `${major_version}.${minor_version}.${patch_version}`;
  const nameVerionName = name || latestVersion;
  await reportVerionsModel.create({
    version_name: nameVerionName,
    version: latestVersion,
    report_id: data._id,
    report: data,
    author: authorId,
  });
  return;
};
const generateReportImage = async (req, res, next) => {
  const _id = req.params.id;
  try {
    await generatePriviewImage(_id, "reports");
    const thumbnail = `${constant.API_URL}/static/screenshot/reports/${_id}.jpeg`;
    const data = await reportModel.findOneAndUpdate(
      { _id },
      { thumbnail },
      { new: true }
    );
    await data.save();
    res
      .status(200)
      .send({ success: true, message: "Thumbnail generated successfully" });
  } catch (error) {
    next(error);
  }
};
const getHTMLandPDF = async (req, res, next) => {
  const _id = req.params.id;
  try {
    let page_url = `${constant.API_URL}/index?report_id=${_id}&type=reports`;
    await generatePDF({ reportId: _id });
    const data = {
      html_url: page_url,
      pdf_url: `${constant.API_URL}/static/pdf/${_id}.pdf`,
    };
    res.status(200).send({
      success: true,
      message: "PDF generated successfully",
      data,
    });
  } catch (error) {
    next(error);
  }
}
// add contributors
const shareReport = async (req, res, next) => {
  /* 	#swagger.tags = ['Reports']
    #swagger.description = 'Share report'
    #swagger.security = [{
        "apiKeyAuth": []
    }]
    #swagger.parameters['obj'] = {
      in: 'params', 
      schema: {
          $id : "615ad4c793a9c76d083fff19"
      },
      in: 'body',
      schema: {
        $contributors: [615ad4c793a92e32432,34lfwe321423c793a92e32432]
      }
    }
*/
  const _id = req.params.id;
  try {
    const report = await reportModel.findOneAndUpdate({ _id }, req.body, { new: true });
    await report.save();
    const authorizationHeaader = req.headers.authorization.split(" ")[1];
    const currentUserDetails = await getCurrentUsersDetails(authorizationHeaader);
    const message = `${currentUserDetails.first_name} shared this report ${report.title} with you.`
    const contributors = req.body.contributors;
    contributors.forEach((userId) => {
      saveNotification(req, "reports", "shared", message, _id, userId);
    });
    return res.status(200).send({ success: true, message: "Your report has been successfully share with the contributors." });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getReports,
  reportDetail,
  storeReport,
  updateReport,
  destoryReport,
  getAuthors,
  getApprovers,
  approveRejectReport,
  cloneReport,
  colaboratedEditing,
  sectionLocking,
  getReportWorkflow,
  updateReportWorkflow,
  getHistory,
  getReportByVersion,
  restoreFromVersion,
  createNamedVersion,
  getStage,
  generateReportImage,
  getHTMLandPDF,
  shareReport
};
