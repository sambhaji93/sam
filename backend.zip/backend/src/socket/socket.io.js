const { NotificationModel } = require("../models/notification");
let socket;
/**
 * @param {*} socket socket.io callback function
 * @returns socet.io connections object
 */
const ioConnectionWrapper = (socket) => socket;
const connection = async (io) => {
  const connection = io.sockets.on("connection", ioConnectionWrapper);
  socket = connection;
  /**
   * Send notification from socket.io when any changes in reports model
   */
  changeStream = NotificationModel.watch();
  changeStream.on("change", (next) => {
    const sendToClient = next.fullDocument;
    socket.emit("notification", JSON.stringify(sendToClient));
  });
};

/**
 * This function just create an event for colaborated editing
 * @param {*} obj namespace or auther editor details
 */
const reportEmitEvent = (obj) => {
  // Data structure of events
  const message = {
    text: obj.text,
    auther: obj.auther,
    id: obj.id,
  };
  // Dynamic event for colaborating editing
  socket.emit(obj.id, message);
};

/**
 * This function will just fire an event to lock section
 * @param {*} obj
 */
const sectionEmitEvent = (obj) => {
  // Data structure of events
  const message = {
    data: obj.data,
    auther: obj.auther,
    id: obj.id,
    ccid: obj.ccid,
    model: obj.model,
    status: obj.status,
    active_author: obj.active_author,
  };
  // Dynamic event for colaborating editing
  socket.emit(obj.id, message);
};

module.exports = {
  connection,
  reportEmitEvent,
  sectionEmitEvent,
};

/**
 * Note: Reference links
 * Client Installation: https://socket.io/docs/v4/client-installation/
 * For Error: https://piyushlabs.com/blog/socket.io-unsupported-protocol-version-error
 */
