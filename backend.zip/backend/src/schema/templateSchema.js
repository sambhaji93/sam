const Joi = require("joi");

const addTemplateSchema = Joi.object()
  .keys({
    group_name: Joi.string().required(),
    description: Joi.string(),
    header: Joi.string(),
    footer: Joi.string(),
    theme: Joi.object(),
    adtional_info: Joi.object(),
    is_page_number: Joi.bool(),
    margin: Joi.object(),
    status: Joi.string(),
  })
  .options({ abortEarly: false });

module.exports = { addTemplateSchema };
