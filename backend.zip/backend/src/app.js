require("dotenv").config();
const express = require("express");
const cors = require("cors");
const server = require('http').createServer();
const http = require("http");
const path = require("path");
const swaggerUi = require("swagger-ui-express");
const swaggerFile = require("../public/api-docs/swagger-output.json");
const router = require("./routes");
var constants = require("./utility/constant");
const { connectToDb } = require("./utility/db");
const { connectToAmqp } = require("./services/amqp");
const socket = require('socket.io')
const { connection } = require('./socket/socket.io')

const app = express();
const port = process.env.NODE_ENV == "test" ? 3001 : process.env.PORT || 3000;
const CORS_OPTIONS = {
  origin: process.env.ORIGIN.split(" "),
  credentials: true,
  optionSuccessStatus: 200,
}
http.globalAgent.keepAlive = true;
server.on('request', app);
app.use("../public", express.static(path.join(__dirname, 'public')));
app.use(express.json({ limit: '50mb' }));
app.use(
  express.urlencoded({
    extended: true,
    limit: '100mb'
  })
);
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(cors(CORS_OPTIONS));

app.use(router);

if (process.env.NODE_ENV === "development") {
  app.use(
    "/api-docs",
    swaggerUi.serve,
    swaggerUi.setup(swaggerFile, constants.SWAGER_OPTIONS)
  );
}

server.listen(port, async () => {
  await connectToDb();
  connectToAmqp();
});

const io = socket(server, {
  allowEIO3: true // false by default
})
// Connection for socket.io
connection(io)
module.exports = app;
